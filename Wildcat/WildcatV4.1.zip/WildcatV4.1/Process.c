/******************** (C) COPYRIGHT 2009 e-Design Co.,Ltd. *********************
 File Name : Process.c       
 Version   : DS203_APP Ver 2.3x                                  Author : bure
*******************************************************************************/
#include "Interrupt.h"
#include "Function.h"
#include "Process.h"
#include "Draw.h"
#include "Menu.h"
#include "BIOS.h"
#include "File.h"

// FFT ////////////////////////////////////////////////////////////////////
s32 fr[FFTSize];		
s32 fi[FFTSize];
u32 NFreq;
char NFreqStr[12];
int imax;			
short PeakFreq;
char PeakFreqStr[12];
char FreqDivStr[12];
char FreqT1Str[12];
////////////////////////////////////////////////////////////////////////////

u32 Sum[4]={0,0,0,0};		//averaging accumulators
u16 NAvg[4]={0,0,0,0};
u16 VNAvg[2]={0,0};
s32 VxAvg[2]={0,0};
s32 VxSsq[2]={0,0};
u32 PxS[4]={0,0,0,0};
u32 TxS[4]={0,0,0,0};
u32 TxN[4]={0,0,0,0};

u16 TaS, TbS, TcS, TdS;            // cycles accumulated
u16 PaS, PbS, PcS, PdS;            // pulse width of the cumulative
u16 TaN, TbN, TcN, TdN;            // Cycle Count
s16  a_Mid_H, a_Mid_L;
s16  b_Mid_H, b_Mid_L;

s32 a_Avg, b_Avg, a_Ssq, b_Ssq;              // use signed integers, allows values at bottom of screen to be read
s16  a_Max, b_Max, a_Min, b_Min;              // 0 levels can get pushed up by calibration, bringing bottom of screen below 0
s16  aT_Max, bT_Max, aT_Min, bT_Min;         // for auto trigger, kept separate from meter data for curdeftime

s16 Posi_412,Posi_41_2, Posi_41, Posi_42, Posi_4_2, Posi_4F1, Posi_4F2, Posi_4F3, Posi_4F4;
s16 c_Max, d_Max, A_Posi, B_Posi;
u8  BailoutFlag=0;
u16 JumpCnt,CountUnread;
u8  FrameMode;
u8  HoldOnNext =0;
u16 bag_max_buf = 4096;
u8  freerun=0;					//flags for auto trig mode
u8  exitflag=0;
u8  entryflag=0;
u8  ADCoffset=54; //shifts ADC/FIFO operating area away from non-linear first xx steps into previously unused linear 200-255 step area
u16 TempKp1=1024;
u8  CalFlag;
u8  CurDefTime=0;			
u8  Options;				//options flag
u8  HoldResetFlag=0;		
s16 Xtend;				//buffer size control
u8  discard=0;				//pre-signal trace blanking
s16 TrigSourceEnable=1;			//for alternate triggering, end of cycling, will go to chA
u32 ReverseBitMask;			
u32 BitMask;
u16 AltHoldoff=0;
s8  OldShift=0;
u8  ClearMeterAreaFlag=0;
u8  ScalingOffset=40;			//centers Ka3 Y-position scaling factor on a step other than 0
                                        //25= same as calibration gain correction (Ka2) zero
                                        //40= same as y-position alignment offset (Ka1) zero calibration point  
u16 QStart[2]={0,0};			//quantization error start/stop reference positions	
u16 QEnd[2]={0,0};
u8  LastA_Mid=0;			//trigger level points for time meter quantization error calculations
u8  LastB_Mid=0;
u8  FirstA_Mid=0;
u8  FirstB_Mid=0;
u8  SumResetFlag=0;			//resets meter summing function
u32 UTmp;
u8  EnablePaS=1;			//controls update speed of PaS and PbS derived calcs (TH, TL, %duty) in large meters
u8  ClearHoldFlag=0;
u8  SlowModeSkip=0;
u8  ClearLeadingEdge=0;			//WAS 0	
u8  FFTflag=0;
u8  Normal=100;
u8  FrameEndFlag;
u8  FFTGain=0;
u16 BufferSize=512;
u8  EnableFFT;
u8 Filter=40;
u8  InitiateNoise;
s32 Waste;
s8  PrevSweepIndex=-1;
u8  ResetFlag=0;
u16 ARBT_ARR;
u8  M_Factor=1;
u8  WaitForTrigFlag=0;
s16 Ch1TLevel=100;
s16 Ch2TLevel=100;
u8  SerialStatus;

void Beeper(u16 ms);					//alarms
void AlternateChannel(void);				//for A&B mode
void SetOffset(u8 channel,u8 range, s16 Ypos);		//sets Ka3,Kb3 zero level reference		
void BatLevelCompensation(void);
s8   InterpolateS8(u8 Ch, s8 L8,s8 H8);			//for battery level comp
u16  InterpolateU16(u8 Ch, u16 L16,u16 H16);
s16  QParam(u8 Ch, u16 Position,u8 service);		//for Qerror
s32  QError(u8 Ch, u16 Start, u16 End, u32 Utmp);	//quantization error compensation
void Average(u8 Ch);
void RunAvg(u8 Ch);
s32  VRunAvg(u8 Ch, s32 Value, s32 Sum);
void cleardatabuf(u8 service);
s32  Log10Process(u16 i);
u8   TriggerModeLogic(void);
void SetIRQ2Priority(void);
void CalculateArbtTimer(void);
void UpdateTLevels(void);

s16 WaveValue(u16 j);
u8  TriggerType=0;

uc16 Wait[22]=        {1000, 500, 200, 100, 65, 30, 20, 10, 5, 3,   			
                       2,      2,   2,   2,  2,  2,  2, 2, 2, 2,    			
                        2,      2};


uc16 shortwait[22]=        {300, 150, 100, 75, 35, 15, 10, 10, 5, 3,   	//for auto trig mode, set time to hold before going auto		
                        2,      2,   2,   2,  2,  2,  2, 2, 2, 2,    			
                        2,      2 };

uc16 TrigDelayLoop[10]= {2,4,10,20,40,100,200,400,1000,2000};		//for trig holdoff, sets how many time loops before allowing rest of program to function

uc16 AltDelay[21]= {1000, 500, 300, 150, 75, 30, 15, 8, 4, 2};          //for alt trig mode, sets time to wait for trigger in other ch if untriggered

uc16 TimeBase[22]= {50000,50000,20000,10000,5000,2000,1000,500,200,100,50,20,10,5,2,1,1,1,1,1,1,1};

Y_attr *Y_Attr; 
X_attr *X_Attr; 
G_attr *G_Attr; 
T_attr *T_Attr;

u32 DataBuf[4096];			//could save 4K of RAM here, using u16 + u8 struct
u8  TrackBuff  [397 * 4];         // curve track: i +0, i +1, i +2, i +3, respectively, placed one on the 4th track data

uc8 Log10Mant[100]={ 0, 0, 3, 5, 6, 7, 8, 8, 9, 10, 0, 4, 8,11,15,18,20,23,26,28,30,32,34,36,38,   //0-9: scale x10, 10-99: scale x100
                    40,41,43,45,46,48,49,51,52,53,54,56,57,58,59,60,61,62,63,64,65,66,67,68,69,
                    70,71,72,72,73,74,75,76,76,77,78,79,79,80,81,81,82,83,83,84,85,85,86,86,87,
                    88,88,89,89,90,90,91,91,92,92,93,93,94,94,95,95,96,96,97,97,98,98,99,99,100};

uc8 Window[512]=       //Hann window
         {0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1,  1,  1,  1,  1,  1,  1,  2,  2,  2,
          2,  2,  3,  3,  3,  4,  4,  4,  4,  5,  5,  5,  6,  6,  6,  7,  7,  8,  8,  8,
          9,  9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15, 16, 17, 17, 18, 18, 19, 
         20, 20, 21, 21, 22, 23, 23, 24, 25, 25, 26, 27, 28, 28, 29, 30, 30, 31, 32, 33,
         33, 34, 35, 36, 37, 37, 38, 39, 40, 41, 41, 42, 43, 44, 45, 46, 46, 47, 48, 49,
         50, 51, 52, 53, 53, 54, 55, 56, 57, 58, 59, 60, 61, 61, 62, 63, 64, 65, 66, 67,
         68, 69, 70, 71, 72, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 84, 85, 
         86, 87, 88, 89, 90, 91, 92, 93, 93, 94, 95, 96, 97, 98, 99,100,101,101,102,103,
        104,105,106,106,107,108,109,110,111,111,112,113,114,115,115,116,117,118,118,119,
        120,121,121,122,123,124,124,125,126,126,127,128,128,129,130,130,131,131,132,133,
        133,134,134,135,135,136,137,137,138,138,139,139,140,140,140,141,141,142,142,143,
        143,143,144,144,144,145,145,145,146,146,146,147,147,147,147,148,148,148,148,148,
        149,149,149,149,149,149,149,150,150,150,150,150,150,150,150,150,150,150,150,150,
        150,150,150,150,150,149,149,149,149,149,149,149,148,148,148,148,148,147,147,147,
        147,146,146,146,145,145,145,144,144,144,143,143,143,142,142,141,141,140,140,140,
        139,139,138,138,137,137,136,135,135,134,134,133,133,132,131,131,130,130,129,128,
        128,127,126,126,125,124,124,123,122,121,121,120,119,118,118,117,116,115,115,114,
        113,112,111,111,110,109,108,107,106,106,105,104,103,102,101,101,100, 99, 98, 97,
         96, 95, 94, 93, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 84, 83, 82, 81, 80, 79,
         78, 77, 76, 75, 74, 73, 72, 72, 71, 70, 69, 68, 67, 66, 65, 64, 63, 62, 61, 61,
         60, 59, 58, 57, 56, 55, 54, 53, 53, 52, 51, 50, 49, 48, 47, 46, 46, 45, 44, 43,
         42, 41, 41, 40, 39, 38, 37, 37, 36, 35, 34, 33, 33, 32, 31, 30, 30, 29, 28, 28,
         27, 26, 25, 25, 24, 23, 23, 22, 21, 21, 20, 20, 19, 18, 18, 17, 17, 16, 15, 15,
         14, 14, 13, 13, 12, 12, 11, 11, 10, 10,  9,  9,  8,  8,  8,  7,  7,  6,  6,  6,
          5,  5,  5,  4,  4,  4,  4,  3,  3,  3,  2,  2,  2,  2,  2,  1,  1,  1,  1,  1,
          1,  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0}; 

 s8  Ka1[10], Kb1[10]; 
 u16 Ka2[10], Kb2[10]; 
 s8  Ka3[10], Kb3[10]; 
 s8  HKa1[10], HKb1[10]; 
 u16 HKa2[10], HKb2[10]; 
 s8  HKa3[10], HKb3[10]; 
 s8  LKa1[10], LKb1[10]; 
 u16 LKa2[10], LKb2[10]; 
 s8  LKa3[10], LKb3[10]; 

u16 HiBatLevel[2]={0,0};		//high battery correction reference level
u16 LoBatLevel[2]={0,0};               //low battery correction reference level
u16 PrevBatLevel=0;		
u16 VDiff[2]={0,0};

D_tab D_Tab[23] ={  // pulse waveform output driver table, based on the 72MHz frequency
//    PSC     ARR       
  { 2400-1,30000-1}, //1  0 
  { 1200-1,30000-1}, //2  1 
  { 480-1, 30000-1}, //5  2 
  { 240-1, 30000-1}, //10  3
  { 120-1, 30000-1},  //20  4
  { 48-1,  30000-1},  //50  5
  { 24-1,  30000-1},  //100  6
  { 12-1,  30000-1},  //200   7
  { 5-1,   28800-1},  //500   8
  { 2-1,   36000-1},  //1K    9
  { 1-1,   36000-1},  //2K    10
  { 1-1,   14400-1},   //5K   11 
  { 1-1,    7200-1},   //10K   12
  { 1-1,    3600-1},   //20K    13
  { 1-1,    1440-1},    //50K   14  
  { 1-1,     720-1},    //100K  15  
  { 1-1,     360-1},    //200K  16  
  { 1-1,     144-1},    //500K  17  
  { 1-1,      72-1},
  { 1-1,      36-1},
  { 1-1,      18-1},
  { 1-1,      12-1},
  { 1-1,       9-1}};   //      22

                                                     //previous versions used 1.8Mhz sampling rate for 25Khz range (@ 72samples/period) 

uc32 A_Freq[18]={1,2,5,10,20,50,100,200,500,1000,2000,5000,10000,20000,50000,100000,200000,500000};

uc8 ScaleIndex[17]={1,1,1,1,1,1,1,1,1,1,1,2,4,10,20,40,80};   //for max DAC sampling rate of 1.8Mhz(DAC is only rated to 1Mhz but seems OK @ 1.8Mhz)
uc16 A_Tab[17]={
    50000-1,                //1Hz uses 36Mhz clock, rest 72Mhz                 	
    50000-1,
    20000-1,
    10000-1,
     5000-1,                //all except noted @ 720 samples/period      (=<1.44Mhz sampling rate)	
     2000-1,
     1000-1,
      500-1,
      200-1,                //500Hz 
      100-1,                //1Khz 
       50-1,                //2Khz 
       40-1,                //5Khz  @ 360 samples/period   (1.8Mhz sampling rate)
       40-1,                //10Khz @ 180 samples/period   (1.8Mhz sampling rate)
       50-1,                //20Khz @ 72 samples/period	   (1.44Mhz sampling rate)
       40-1,                //50Khz @ 36 samples/period    (1.8Mhz sampling rate)    14
       40-1,                //100Khz@ 18 samples/period    (1.8Mhz sampling rate)
       40-1};               //200Khz@  9 samples/period    (1.8Mhz sampling rate)


s16   ATT_DATA[720];    //could go up to 2880 to allow long arb digital streams

sc16 SIN_QUAD[181]={    2048 , 2066 , 2084 , 2102 , 2119 , 2137 , 2155 , 2173 , 2191 , 2209 , 2226 ,
			2244 , 2262 , 2280 , 2297 , 2315 , 2333 , 2351 , 2368 , 2386 , 2403 , 2421 ,
			2439 , 2456 , 2474 , 2491 , 2508 , 2526 , 2543 , 2561 , 2578 , 2595 , 2612 ,
			2629 , 2646 , 2664 , 2681 , 2698 , 2714 , 2731 , 2748 , 2765 , 2782 , 2798 ,
			2815 , 2831 , 2848 , 2864 , 2881 , 2897 , 2913 , 2929 , 2945 , 2961 , 2977 ,
 			2993 , 3009 , 3025 , 3040 , 3056 , 3072 , 3087 , 3102 , 3118 , 3133 , 3148 ,
 			3163 , 3178 , 3193 , 3207 , 3222 , 3237 , 3251 , 3266 , 3280 , 3294 , 3308 ,
 			3322 , 3336 , 3350 , 3364 , 3377 , 3391 , 3404 , 3418 , 3431 , 3444 , 3457 ,
 			3470 , 3483 , 3495 , 3508 , 3520 , 3533 , 3545 , 3557 , 3569 , 3581 , 3593 ,
 			3605 , 3616 , 3628 , 3639 , 3650 , 3661 , 3672 , 3683 , 3693 , 3704 , 3714 ,
 			3725 , 3735 , 3745 , 3755 , 3765 , 3774 , 3784 , 3793 , 3803 , 3812 , 3821 ,	
			3830 , 3838 , 3847 , 3855 , 3864 , 3872 , 3880 , 3888 , 3896 , 3903 , 3911 ,
			3918 , 3925 , 3932 , 3939 , 3946 , 3953 , 3959 , 3965 , 3972 , 3978 , 3983 ,
 			3989 , 3995 , 4000 , 4006 , 4011 , 4016 , 4021 , 4025 , 4030 , 4034 , 4038 ,
 			4043 , 4046 , 4050 , 4054 , 4057 , 4061 , 4064 , 4067 , 4070 , 4073 , 4075 ,
 			4077 , 4080 , 4082 , 4084 , 4086 , 4087 , 4089 , 4090 , 4091 , 4092 , 4093 ,
			4094 , 4094 , 4095 , 4095 , 4095  };

sc16 Sine100K[18]=                                                                                                                   //         
  {0x9C0,0xC59,0xE68,0xFAB,          
   0xFFF,0xF70,0xDF5,0xBBD,0x90E,    
   0x63E,0x3A5,0x196,0x053,
   0x000,0x08E,0x209,0x441,0x6F0};         

sc16 Sine200K[9]=                    
  {0xC59,0xFAB,                      
   0xF70,0xBBD,                      
   0x63E,0x196,
   0x000,0x209,0x6F0};                     

sc16 Triangle100K[18] =              
  {0x8E2,0xAA9,0xC70,0xE37,          
   0xFFE,0xE37,0xC70,0xAA9,0x8E2,    
   0x71B,0x554,0x38D,0x1C6,
   0x000,0x1C6,0x38D,0x554,0x71B};         

sc16 Triangle200K[9] =               
  {0xAA9,0xE37,                      
   0xE37,0xAA9,                      
   0x71B,0x38D,
   0x000,0x38D,0x71B};                     

sc16 DIGI_DATA[2] =  // Square wave data                                                                                             //         
  {2047,-2048};    

void BackGround_Reset(void)
{ 
  u8 i, j;
  u8 TitleLimit=13;
  if ((FlagMeter==2)&&(UpdateMeter!=4))TitleLimit=11;
  __Clear_Screen(BLACK);
  Delayms(100); 
  for(i=0; i<TitleLimit; i++) for(j=0; j<4; j++) Title[i][j].Flag |= UPDAT;

  for(i=0; i<9; i++)                     Meter[i].Flag    |= UPDAT;
  if(Current != FILE) {
    Title[FILE][0].Flag &= !UPDAT;
    Title[FILE][1].Flag &= !UPDAT;
    Title[FILE][3].Flag &= !UPDAT;
  }  
   Update = 1;                  // return back the jumper settings
   ClearMeterAreaFlag=1;
   InitXY=1;
}

/*******************************************************************************
 App_init: Displays the window waveform data initialization
*******************************************************************************/
void App_init(void)
{ 
  __Set(ADC_CTRL, EN );       
  __Set(STANDBY, DN);          // exit the power saving state
  Delayms(20); 
  __Set(FIFO_CLR, W_PTR); 
  BackGround_Reset();
  PD_Cnt = 600;
}

/*******************************************************************************
 Update_Range: 
*******************************************************************************/
void Update_Range(void) 
{
u8 Amode=Title[TRACK1][COUPLE].Value;
u8 Bmode=Title[TRACK2][COUPLE].Value;
if (Amode==2){Amode--;Det|=1;}else Det&=2;              //use AC for coupling in detector mode
if (Bmode==2){Bmode--;Det|=2;}else Det&=1;
if (Amode>2)Amode=0;                                    //DC coupling for serial decode
if (Bmode>2)Bmode=0;                                   

  __Set(CH_A_COUPLE, Amode);
  __Set(CH_A_RANGE,  Title[TRACK1][RANGE].Value);
  SetOffset(0,_A_Range,_1_posi);
  __Set(CH_B_COUPLE, Bmode);
  __Set(CH_B_RANGE,  Title[TRACK2][RANGE].Value);
  SetOffset(1,_B_Range,_2_posi);

  if(SerialStatus)UpdateTLevels();

  if((Sweep)||(Det)){
    Update_Output();
    if(Title[TRIGG][SOURCE].Value==4) Update_Trig(0); else Update_Trig(1);
  }
}
/*******************************************************************************
 Update_Base: 
*******************************************************************************/
void Update_Base(void) 
{
  u16 i;
  
  __Set(ADC_CTRL, EN);       
  i = Title[T_BASE][BASE].Value;     
  __Set(T_BASE_PSC, X_Attr[i].PSC);
  __Set(T_BASE_ARR, X_Attr[i].ARR);

  Wait_Cnt = Wait[_T_base];
  if(_Status == RUN) __Set(FIFO_CLR, W_PTR);      // FIFO write pointer reset
  if(_T_base>16){if(Title[TRIGG][SOURCE].Value==4) Update_Trig(0); else Update_Trig(1);}
  JumpCnt=0;

}
/*******************************************************************************
 Update_Output: 
*******************************************************************************/
void Update_Output(void) {
u16 i; 

  if(_Frqn==0)TIM7->PSC=1; else TIM7->PSC=0;                  //set DAC clock to 36Mhz for 1Hz to avoid ARR overload, 72Mhz for rest
  SetIRQ2Priority();
  TIM_2IRQControl();
  if(Title[TRIGG][SOURCE].Value==4) Update_Trig(0); else Update_Trig(1);
  M_Factor=1;

  TIM4->CR1   =  0x0080;            // SQR_OUT = Disable. Stops counter 0x80=auto reload preload enable
  TIM4->DIER  =  0x0000;            // disable TIM4_INT  
  TIM4->CR2   =  0x0000;            // disable update event as output

if(ResetFlag){
  TIM4->EGR=0x0001;                 // generate update event for full reset 
  TIM2->EGR=0x0001;                 
  ResetFlag--;
}
  DAC->CR     =  0x00000000;        // reset both channels   

  if(_Kind == PWM){                        //(4)

    if(Det){                               //if in detector mode, initialize analog as well as it uses this along with PWM
      Title[OUTPUT][DUTYPWM].Value=15000;
      DMA2_Channel4->CCR &= ~DMA_CCR1_EN;
      for(i=0;i<720;i++)ATT_DATA[i]=2048;
      ResetDMA2_Ch4Params(72);
      __Set(ANALOG_ARR, 40-1);
    }
    __Set(DIGTAL_PSC, D_Tab[_Frqn].PSC);
    __Set(DIGTAL_ARR, D_Tab[_Frqn].ARR);

    i=((D_Tab[_Frqn].ARR+1)*(30000-Title[OUTPUT][DUTYPWM].Value))/30000;
    if(i==0)i++;
    if(i>(D_Tab[_Frqn].ARR+1))i=(D_Tab[_Frqn].ARR+1);

    if((Sweep==1)||(PWAdjustMode==0)){
      __Set(DIGTAL_CCR,i);
    }else{
        GPIOB->CRL &= 0xF0FFFFFF;  
        GPIOB->CRL |= 0x0B000000;
        TIM4->CR1 = 0x0081;
      }

  }else if(_Kind==5){                  // random noise mode

    if(_Frqn>18)_Frqn=18;              // DAC refresh limit, 1Mhz 
    InitiateNoise=1;
    if(PrevSweepIndex<0)PrevSweepIndex=SweepIndex;
    DMA2_Channel4->CCR &=0xFFFFFFFE;   // release DMA channel from DAC 
    GPIOB->CRL  = 0x34BBB438;          // puts PWM port(TIM4/PB6) in input, floating mode + configures other bits  
    GPIOA->CRL  = 0x110011BB;          // puts DAC2 port (PA5) in input, analog mode

    if(_Frqn<8)i=_Frqn+6;              // 100x averaging filter @ <500hz
      else if(_Frqn<14)i=_Frqn+3;      // 10x filter for 500hz - 20Khz
        else i=_Frqn;                  // above 20Khz no filtering
    TIM4->PSC   = D_Tab[i].PSC;        // oversampling setup                 
    TIM4->ARR   = D_Tab[i].ARR;      

    if(_Frqn<16){
      TIM4->DIER|=0x0001;              // enable TIM4_INT, engages seeding @ <200Khz and filters for frequencies <=20Khz
    }else{
      TIM4->DIER=0x0000;               // seeding by TIM2_INT for freq limits > 100Khz 
      SweepIndex=_Frqn-13;                     
    }
    TIM_2IRQControl();

    TIM4->CR2   = 0x0020;              // use update event as output
    TIM4->CR1   = 0x0085;              // turn on DAC2 clock, preload arr, update only on overflow 

    if(_Frqn<14){
      DAC->CR       = 0x0B6C002C;      // set up both DACs to trigger from TIM4 update event: DAC2=generator > filter > DAC1=output
      DAC->CR      |= 0x00010001;      // enable both channels   
    }else{                             // above 20Khz
      DAC->CR       = 0x00000B6C;      // set up DAC1 for generator and output
      DAC->CR      |= 0x00000001;      // enable DAC1   
    }
    return;

  }else if(_Kind==6){                  // generator turned off    DAC, PWM and TIM4_INT already shut down at top of function
                                       // shut down additional resources + set output low
    DMA2_Channel4->CCR&= 0xFFFFFFFE;   // release DMA channel from DAC 
    TIM7->CR1          = 0x0084;       // shut off DAC timer
    GPIOA->CRL        |= 0x00040000;   // disconnect DAC if connected
    GPIOB->CRL        &= 0xF0FFFFFF;   // reset bit 6 control
    GPIOB->CRL        |= 0x03000000;   // enable bit 6 as output
    GPIOB->ODR        &= 0x0000FFBF;   // reset bit 6 to set gen output low
    if(PrevSweepIndex<0)PrevSweepIndex=SweepIndex;
    return; 

  }else if(_Kind==7){                  //arbitrary waveforms

     while((ArbtSampleNumber*A_Freq[_Frqn])>1800000)_Frqn--;          //limit frequency range so sampling rate is <1.8Mhz
     Title[OUTPUT][1].Flag|= UPDAT;
     DMA2_Channel4->CCR &= ~DMA_CCR1_EN;
     ResetDMA2_Ch4Params(ArbtSampleNumber);
     CalculateArbtTimer();

  }else{

     if(_Frqn>16)_Frqn=16;
     DMA2_Channel4->CCR &= ~DMA_CCR1_EN;
     WaveGen();
     ResetDMA2_Ch4Params(720/ScaleIndex[_Frqn]);
     __Set(ANALOG_ARR, A_Tab[_Frqn]);
  }

  if(PrevSweepIndex>=0){SweepIndex=PrevSweepIndex;PrevSweepIndex=-1;}
  if(GenAdjustMode==0){GenFreqShift=0;PrevShift=0;}

  OutputAdjust();
}


void ResetDMA2_Ch4Params(u32 Count){          //This is an attempt to fix a *very* occasional loss of this DMA function while quickly
  DMA2_Channel4->CPAR=DHR12R1_DAC;            //shifting some gen menu functions by holding down repeat keys, requiring reboot. All relevant parms now reset 
  __Set(ANALOG_PTR, (u32)ATT_DATA);           //DMA ch needs to be disabled before calling
  __Set(ANALOG_CNT, Count);
  DMA2_Channel4->CCR =0x00003000;             //priority
  DMA2_Channel4->CCR|=0x000005B0;             //setup
  DMA2_Channel4->CCR|=0x00000002;             //turn transfer complete int on
  DMA2_Channel4->CCR|=0x00000001;             //enable
  DMA2->IFCR|=0x00002000;                     //clear transfer complete int flag
  TIM7->DIER=0x0100;                          //enable DMA call
  TIM7->CR2 =0x0000;                          //system (V1.50-1.60, others?) sets bit 3 here for DMA call on update event, no such function on basic timers
}


void CalculateArbtTimer(void){
u32 X;
u16 Y;

  X=72000000/(ArbtSampleNumber*A_Freq[_Frqn]);
  if(X<10000){
    TIM7->PSC=0;
    ARBT_ARR=X-1;    
  }else{
    Y=X/10000;
    while((X%Y)!=0)Y++;          //  find an integral divider
    if(Y>(X/Y)){                 //  if divider larger than divided, use as ARR so freq shift function can work correctly
      TIM7->PSC=(X/Y)-1;             
      ARBT_ARR=(Y-1);             
    }else{
      TIM7->PSC=(Y-1);    
      ARBT_ARR=(X/Y)-1;          
    } 
  }
  __Set(ANALOG_ARR,ARBT_ARR);
}

/*******************************************************************************
 Update_Trig: 
*******************************************************************************/
void Update_Trig(u8 service) 
{ 
u16 a;
u16 b;
u32 UTmp;

  TriggerType=_Tr_kind;

  a=((TempKp1*_T1)+512)/1024;           //compensate for interpolated ranges
  b=((TempKp1*_T2)+512)/1024;
                                      
   if(_Tr_kind==8){
     if((Sweep)&&(_Kind<5)){
       UTmp=((1000/((TIM2Speed[SweepIndex]*SweepStep*5)/SweepMod))*750)/TimeBase[_T_base];    //calculate optimum period to trigger on
       if(UTmp>200)UTmp=200;                                                                  
       __Set(T_THRESHOLD,UTmp);

       if(service){       
         if(Title[TRIGG][SOURCE].Value == TRACK1){
           if(_Vt1>_1_posi)TriggerType=5;else TriggerType=7;  
         }
         if(Title[TRIGG][SOURCE].Value == TRACK2){ 
           if(_Vt2>_2_posi)TriggerType=5;else TriggerType=7;  
         } 
       }else{
         if(TrigSourceEnable == TRACK1){                                  
           if(_Vt1>_1_posi)TriggerType=5;else TriggerType=7;  
         }
         if(TrigSourceEnable == TRACK2){ 
           if(_Vt2>_2_posi)TriggerType=5;else TriggerType=7;  
         } 
       }

       if((_Kind==PWM)&&((Sweep>1)||(Det==0)))TriggerType=5;                     

     }else{
       TriggerType=3;                                                                //trigger on positive transition of continuous wave
    }

   }else{
     if(_T1 > _T2)  __Set(T_THRESHOLD,a-b);    
     else           __Set(T_THRESHOLD,b-a); 	 
   }
                                                                                                 
  //a=((((_Vt1-Ka1[_A_Range]-_1_posi)*1024)/Ka2[_A_Range])+ADCoffset+_1_posi)&0xFF;  //this should be what we want (u8 in FPGA call)  
  //b=((((_Vt2-Kb1[_B_Range]-_2_posi)*1024)/Kb2[_B_Range])+ADCoffset+_2_posi)&0xFF;  
  a=((((_Vt1-Ka1[_A_Range]-_1_posi)*1024)/Ka2[_A_Range])&0xFF)+ADCoffset+_1_posi;    //works through u32>u8 conversion in Set_Param()  
  b=((((_Vt2-Kb1[_B_Range]-_2_posi)*1024)/Kb2[_B_Range])&0xFF)+ADCoffset+_2_posi;   

  UpdateTLevels();

 if(TriggerType>7)TriggerType=3;               

 if(_T_base>18){                                  //use time based triggering for fastest timebases rather than edge or level trig
   if((TriggerType==0)||(TriggerType==2)){        //more reliable for random or occasional triggers for some reason
     TriggerType=7;                               //triggers if time exceeds threshold 
     __Set(T_THRESHOLD,0);                        //setting time to exceed at 0 turns these into an edge or level trigger
   }
   if((TriggerType==1)||(TriggerType==3)){
     TriggerType=5;
     __Set(T_THRESHOLD,0);
   }
 }

 if(service){
  __Set(TRIGG_MODE,  (_Tr_source<< 3)+TriggerType);
  if(Title[TRIGG][SOURCE].Value == TRACK1){ 
  __Set(V_THRESHOLD,a); 
  }
  if(Title[TRIGG][SOURCE].Value == TRACK2){ 
  __Set(V_THRESHOLD,b); 
  }

 }else{
  __Set(TRIGG_MODE,  (TrigSourceEnable<< 3)+TriggerType);
  if(TrigSourceEnable == TRACK1){ 
  __Set(V_THRESHOLD,a); 
  }
  if(TrigSourceEnable == TRACK2){ 
  __Set(V_THRESHOLD,b); 
  }
 }
}

void UpdateTLevels(void){
  Ch1TLevel=(((_Vt1-Ka1[_A_Range]-_1_posi)*1024)/Ka2[_A_Range])+_1_posi;
  Ch2TLevel=(((_Vt2-Kb1[_B_Range]-_2_posi)*1024)/Kb2[_B_Range])+_2_posi;
}

/*******************************************************************************
 Process: Calculate processing buffer data
*******************************************************************************/
void Process(void)
{ 
  s16 i, j = 0, k, V[8] = {0},a,b, n = 0,WindowPosition;
  s32 Tmp=0;
  u8  Ch[4], C_D=0;
  s8  Sa = 2, Sb = 2, Sc = 2, Sd = 2;     // time status
  u16 Ta, Tb, Tc, Td;                     // pulse width count
  u16 Pa, Pb, Pc, Pd;			  // holds + side transition of wave for PaS
  u8  jj;
  s16 h;
  s16 start;                              //for cursor defined meters
  u16 finish;
  s8  Shift=0;				  //jitter compensation value
  u8  TriggerPosition=150;
  u8  DTriggerPosition=150;
  u8  TimeCalcHyst=2;			  //time based calculations trigger point hysteresis value
  s16  AWavCenter;                          
  s16  BWavCenter;
  s32  X=0,Y=0;
  u16  LeftSkirt=0;

  if(UartLogic()||i2cLogic()||SpiLogic())SerialStatus=1;else SerialStatus=0;
  Ta = Tb = Tc = Td = 0;
  Pa = Pb = Pc = Pd = 0;

  TaS = 0; TbS = 0; TcS = 0; TdS = 0; 
  PaS = 0; PbS = 0; PcS = 0; PdS = 0; 
  TaN = 0; 
  TbN = 0; TcN = 0; TdN = 0; 

  Posi_412 = _4_posi - _1_posi - _2_posi;
  Posi_41_2 = _4_posi - _1_posi + _2_posi;
  Posi_41  = _4_posi - _1_posi;
  Posi_42  = _4_posi - _2_posi;
  Posi_4_2 = _4_posi + _2_posi;
  Posi_4F1 = _4_posi - FileBuff[ 399];
  Posi_4F2 = _4_posi - FileBuff[ 799];
  Posi_4F3 = _4_posi - FileBuff[ 1199];
  Posi_4F4 = _4_posi - FileBuff[1599];

  A_Posi   = _1_posi-Ka1[_A_Range];    
  B_Posi   = _2_posi-Kb1[_B_Range];    
  
  a_Max=-0x7FFF;a_Min=0x7FFF;          //in case max is negative or min is positive (as with DC voltages)	
  b_Max=-0x7FFF;b_Min=0x7FFF;          //originally would initiate @i=0 but with init @i=4 could transfer in slow mode before init

  aT_Max = A_Posi; bT_Max = B_Posi;    // Used for calculating auto trigger
  aT_Min = A_Posi; bT_Min = B_Posi;             

  if((_3_posi + 20)>= Y_BASE+Y_SIZE)  c_Max = Y_BASE+Y_SIZE-1;
  else                                c_Max = _3_posi + 20;
  if((_4_posi + 20)>= Y_BASE+Y_SIZE)  d_Max = Y_BASE+Y_SIZE-1;
  else                                d_Max = _4_posi + 20;

     if ((((_Mode==NORH)||(_Mode==NORHLD)||(_Mode==NORC))&&(_T_base < 10)&&(Options&1))||(_4_source>9)){
       Xtend=150;							//stabilize buffer size in holdoff mode to cover pre-trigger section
     }else{								//optimize size for best aquisition
       Xtend=_X_posi.Value;
       if (FlagMeter>0) Xtend-=86;
     } 
     if(_4_source>9)Xtend+=56; else if(Det)Xtend+=20;                   //cover right end of FFT buffer or averaging filter in detector mode

      if(TriggerModeLogic())TriggerPosition=149;else TriggerPosition=150;		//time based triggers occur 1 sample earlier

      switch (_T_base){									//digital ch trig positions for interpolated ranges
        case 17:
	  DTriggerPosition=149;
          break;
        case 18:
	  DTriggerPosition=148;
          break;
        case 19:                                                 
          if(TriggerModeLogic())DTriggerPosition=147;else DTriggerPosition=148;		
          break;
        case 20:
          if(TriggerModeLogic())DTriggerPosition=146;else DTriggerPosition=147;		
          break;
        case 21:
          if(TriggerModeLogic())DTriggerPosition=145;else DTriggerPosition=146;		
      }

    if(_Status==RUN)TempKp1=_Kp1;	                   // eliminates improper change of wave timebase by Kp1 while in hold mode at faster timebases
    k =((1024 - TempKp1)*TriggerPosition + 512)/1024 + _X_posi.Value;  // window position in the calculation of the interpolation of the correction value

    WindowPosition=_X_posi.Value;                            
    Tmp=1792/Int_sqrt(TempKp1);
    if(WindowPosition>Tmp)WindowPosition-=Tmp; else        // shift window back to center FFT over display 
      WindowPosition=0;
    if(WindowPosition>3582)WindowPosition=3582;            // FFT window is 512, need to keep from going past last samples

    start=(((((TempKp1*1000)/1024)*Title[T_VERNIE][0].Value)+500)/1000)+k-((1024/TempKp1)/4);	//calculate start/stop positions for
    if((_T_base==20)&&(Title[7][0].Value<2))start--; 						//cursor defined meters
    if(_T_base==19)start--; 
    if((_T_base==18)&&(Title[7][1].Value>3))start--; 
    finish=(((((TempKp1*1000)/1024)*Title[T_VERNIE][1].Value)+500)/1000)+k;    

    if ((Title[TRIGG][SOURCE].Value>1)&&(Title[TRIGG][SOURCE].Value<4)){start+=5;finish+=5;}      // adjust to align with shifted wave when triggering from dig ch

    if(_Mode==X_Y){if(Title[6][3].Value<16)Title[6][3].Value=16;BufferSize=Title[6][3].Value*16;}
    bag_max_buf = get_bag_max_buf();

    if(Title[T_VERNIE][T1].Value==0)start=0;			// lock out time cursors from restricting measurements if
    if(FlagMeter){                                              // at extreme right or left in cursor defined meter mode
      if(Title[T_VERNIE][T2].Value==300)finish=bag_max_buf;
    }else{
      if(Title[T_VERNIE][T2].Value==386)finish=bag_max_buf;
    }

    if (CurDefTime==0){			
      NSamples=(bag_max_buf-4);			//count starts @ i=4 to eliminate noise on some ranges			
      a_Avg=NSamples/2;
      b_Avg=NSamples/2;
    }else{
       if (finish>start){
         NSamples=(finish-start);
         if (NSamples>1){
	    NSamples--;
            a_Avg=NSamples/2;
            b_Avg=NSamples/2;
         }else{
          a_Avg=A_Posi;
          b_Avg=B_Posi;
         }
       }else{
        NSamples=1;
        a_Avg=A_Posi;
        b_Avg=B_Posi;
       }
    }  
    a_Ssq=b_Ssq=NSamples/2;
    if((_4_source==15)||(_4_source==13))Normal=100; else Normal=80;                //normalize FFT levels

    if ((exitflag==1)&&(JumpCnt!=0)) exitflag=0;      // leave exitflag on at beginning of frame so if complete frame is done, allow freerun 

  for(i=0; i <bag_max_buf; i++){

    if(    (   (  (_T_base>10) || ( (_T_base>9) && (FrameMode==0) && (((_Kind==5)&&(_Frqn>11))||(ShowFFT==1)) )  )   
      ||   (freerun==1)   ||   (  (_T_base>9)&&( (Tim2Factor>20)||(((FrameMode==0)&&(SerialStatus))||(SpiLogic())) )  )
        ||      (   ( (_Mode==X_Y)||((SpiLogic())&&(FrameMode==0)&&(SpiChartFlag)&&((_3_source)||(SpiNumBits==7)||(SpiNumBits==8))
          &&(ArrayIndex>47))) && (_T_base>8)  )   )    &&    (_Status == RUN)    ){

      Tmp=Update;                                                                                    //compiler optimizations: need to do something significant with Tmp or it dismisses the the while loops
      if((FrameMode==0)&&(_T_base==10)&&(((_Kind==5)&&(_Frqn>11))||(ShowFFT==1)||(Tim2Factor>20))){
        while(1){if(Tmp++>50)break;}                                                                 //Proper timing for 500uS timebase in full buffer mode under various conditions
        if((_Mode==NORHLD)&&((_Kind==5)&&(_Frqn>15)))while(1){if(Tmp++>100)break;}
      }
      Tmp=0; 
      if((FrameMode==0)&&(_T_base==11)&&(Sweep)&&(SweepIndex<6))while(1){if(Tmp++>25)break;}         //timing for 200uS timebase
      Waste=Tmp;                                      

      if(Title[TRIGG][SOURCE].Value==4) TransferFIFO(i,1); else TransferFIFO(i,0);   

    }else if((__Get(FIFO_EMPTY)==0)&&(i == JumpCnt)&&(_Status == RUN)){
      JumpCnt++;
      if(Title[TRIGG][SOURCE].Value==4) TransferFIFO(i,1); else TransferFIFO(i,0);
    }

      Ch[A] = (DataBuf[i] & 0xFF );              	      // now only used for time measurements	
	V[A]=(Ch[A]-ADCoffset);				      // for wave trace,(also now used for meters, with signed vars) load into signed var and no clipping
        if(V[A]<-15)V[A]=-15;				      // limit to prevent overload in FFT with greater than full screen waveforms	
	if (Ch[A]<ADCoffset) Ch[A]=ADCoffset;       	      // clip at new 0 level, needed for unsigned var	    	
	Ch[A]-=ADCoffset;				      // with ypos shift canceling this, moves operating point back to normal	

      Ch[B] = ((DataBuf[i] >> 8) & 0xFF);
	V[B]=(Ch[B]-ADCoffset);
        if(V[B]<-15)V[B]=-15;
	if (Ch[B]<ADCoffset) Ch[B]=ADCoffset;               	    	
	Ch[B]-=ADCoffset;

	  if(i == 4) {								// used for auto trigger
	      aT_Max = V[A];	// statistics channel A maximum
		aT_Min = aT_Max;	// statistics channel A minimum
		bT_Max = V[B];	// statistics channel B maximum
		bT_Min = bT_Max;	// statistics channel B minimum
	  }else{         				  // not the first values
  		if(V[A] > aT_Max)  aT_Max = V[A];         // statistics channel A maximum
		if(V[A] < aT_Min)  aT_Min = V[A];         // statistics channel A minimum
		if(V[B] < bT_Min)  bT_Min = V[B];         // statistics channel B minimum
		if(V[B] > bT_Max)  bT_Max = V[B];         // statistics channel B maximum
	  }


		// FFT ///////////////////////////////////////  


           if((i>=WindowPosition)&&(i < (FFTSize+WindowPosition))&&(_Mode!=X_Y)&&((EnableFFT==0)||(_T_base>7)  ||(_Mode==SCAN)  )){

		if ( ((_4_source==SPEC_A)&&(_2_source))  || (_4_source==13)||(_4_source==12)){
                  fr[i-WindowPosition]=(((V[B]-_2_posi)*Window[i-WindowPosition])/Normal)<<(2+FFTGain);  			     
                }     
		if ( ((_4_source==SPEC_A)&&(_1_source))  || (_4_source>13) ){
                  fr[i-WindowPosition]=(((V[A]-_1_posi)*Window[i-WindowPosition])/Normal)<<(2+FFTGain);
                }
            }

		////////////////////////////////////// FFT ///

      if (i>5) {C_D = DataBuf[i-6] >>16;}else C_D=0;	  // align digital chs with analogs

//if(FlagMeter>0){	//could be used to speed up display refresh rate when meters are turned off?
      if (((CurDefTime==0)&&(i>3)&&(i<bag_max_buf))||((i>start)&&(i<finish))){		//for voltage measurements, only for analog channels

        a_Avg += V[A];                                    // use signed vars, otherwise, values at bottom of screen, pushed up by Kx1, now below zero, fail to register
        Tmp = V[A]- A_Posi;
        a_Ssq +=(Tmp * Tmp);                              // statistical sum of squares of the A channel

        b_Avg += V[B];                                    // cumulative average channel B, DC
        Tmp = V[B]- B_Posi;
        b_Ssq +=(Tmp * Tmp);                              // statistical sum of squares of the B channel

	  if((i == 4)||((CurDefTime>0)&&(i==(start+1)))) {		  // read first values - max = min = values
	        a_Max = V[A];	// statistics channel A maximum
		a_Min = a_Max;	// statistics channel A minimum
		b_Max = V[B];	// statistics channel B maximum
		b_Min = b_Max;	// statistics channel B minimum
	  }else{			                // not the first values
  		if(V[A] > a_Max)  a_Max = V[A];         // statistics channel A maximum
		if(V[A] < a_Min)  a_Min = V[A];         // statistics channel A minimum
		if(V[B] < b_Min)  b_Min = V[B];         // statistics channel B minimum
		if(V[B] > b_Max)  b_Max = V[B];         // statistics channel B maximum
	  }
      }

     if ((CurDefTime==0)||((i>start-1)&&(i<(finish+1)))){	//for time related measurements for both dig and analog channels

      if((i>3)&&(i<(bag_max_buf-3))){ 

       if((CurDefTime==0)||(i<finish)){

        if(Ch[A] > a_Mid_H){
          if (Sa<2){					//don't initiate if value is above trigger point when starting out
            if(Sa == 0){
		  TaS = i;                    					
                  LastA_Mid=a_Mid_H;			//save relevant time meter trigger level for quantization compensation
              if(Ta==0){				//use Ta to initiate
                  Ta=i;					//first + crossing point saved 
                  QStart[0]=i;				//start position saved for quantization calcs 
                  FirstA_Mid=a_Mid_H;
		  }else{				//after initialized, count + crossings, add + wave sampling count to PaS
		    TaN++;                              //increment TaN only after initial crossing point saved
		    PaS += Pa;				//only add positive part if whole wave is considered	
              }
		}
            Sa = 1;  
          } 
        } else { 
          if(Ch[A] < a_Mid_L){
            if(Sa == 2){
		  Sa=0; 				//initiate only after going below trigger point so partial wave does not get counted
		  PaS=0;				//initiate PaS
            }
	      if(Sa == 1){
                  Sa = 0;
		  Pa = i-TaS;				//save for PaS
            }
          }
        }

       if(Ch[B] > b_Mid_H){
          if (Sb<2){					
            if(Sb == 0){
		  TbS = i;                    					
                  LastB_Mid=b_Mid_H;			//save relevant time meter trigger level for quantization compensation
              if(Tb==0){				
                  Tb=i;					 
                  QStart[1]=i;				//start position saved for quantization calcs 
                  FirstB_Mid=b_Mid_H;
		  }else{
		    TbN++;                         
		    PbS += Pb;					
              }
		}
            Sb = 1;  
          } 
        } else { 
          if(Ch[B] < b_Mid_L){
            if(Sb == 2){
		  Sb=0; 					
		  PbS=0;					
            }
	      if(Sb == 1){
              Sb = 0;
		  Pb = i-TbS;				
            }
          }
        }
       }  

    if((i>10)&&((CurDefTime==0)||(i>start))){                        //eliminate noise at start of wave causing errors in dig channels

       if(C_D & 1){
          if (Sc<2){					
            if(Sc == 0){
		  TcS = i;                    					
              if(Tc==0){				
                Tc=i;					 
		  }else{
		    TcN++;                         
		    PcS += Pc;					
              }
		}
            Sc = 1;  
          } 
        } else { 
            if(Sc == 2){
		  Sc=0; 					
		  PcS=0;					
            }
	      if(Sc == 1){
              Sc = 0;
		  Pc = i-TcS;				
            }
	  } 

       if(C_D & 2){
          if (Sd<2){					
            if(Sd == 0){
		  TdS = i;                    					
              if(Td==0){				
                Td=i;					 
		  }else{
		    TdN++;                         
		    PdS += Pd;					
              }
		}
            Sd = 1;  
          } 
        } else { 
            if(Sd == 2){
		  Sd=0; 					
		  PdS=0;					
            }
	      if(Sd == 1){
              Sd = 0;
		  Pd = i-TdS;				
            }
        }

      }	//if i>8
    } //if i>3
  }  //if curdeftime
//}    //if flagmeter>0


                                                                                                               //calculate jitter
      if((i==TriggerPosition)&&(_T_base > 16)&&(_Mode!=SCAN)&&(__Get(FIFO_START)!=0)){				//analog channels
        if((Title[7][1].Value==1)||(Title[7][1].Value==3)||(Title[7][1].Value==4)||(Title[7][1].Value==5)){	//positive transitions
          if ((Title[7][0].Value==0)||((Title[TRIGG][SOURCE].Value==4)&&(TrigSourceEnable==0))){										//select trigger channel
            b=(Ka1[_A_Range]+A_Posi+(Ka2[_A_Range]*(V[A]-A_Posi)+ 512)/1024)-_Vt1;
	    a=_Vt1-(Ka1[_A_Range]+A_Posi+(Ka2[_A_Range]*(((DataBuf[TriggerPosition-1]& 0xFF)-ADCoffset)-A_Posi)+ 512)/1024);        
          }else if((Title[7][0].Value==1)||((Title[TRIGG][SOURCE].Value==4)&&(TrigSourceEnable==1))){
            b=(Kb1[_B_Range]+B_Posi+(Kb2[_B_Range]*(V[B]-B_Posi)+ 512)/1024)-_Vt2;
	    a=_Vt2-(Kb1[_B_Range]+B_Posi+(Kb2[_B_Range]*((((DataBuf[TriggerPosition-1]>>8)&0xFF)-ADCoffset)-B_Posi)+ 512)/1024);        
          }else goto bypasscalculate;
        }else{													//negative transitions
          if ((Title[7][0].Value==0)||((Title[TRIGG][SOURCE].Value==4)&&(TrigSourceEnable==0))){										
            b=_Vt1-(Ka1[_A_Range]+A_Posi+(Ka2[_A_Range]*(V[A]-A_Posi)+ 512)/1024);
	    a=(Ka1[_A_Range]+A_Posi+(Ka2[_A_Range]*(((DataBuf[TriggerPosition-1]& 0xFF)-ADCoffset)-A_Posi)+ 512)/1024)-_Vt1;        
          }else if((Title[7][0].Value==1)||((Title[TRIGG][SOURCE].Value==4)&&(TrigSourceEnable==1))){
            b=_Vt2-(Kb1[_B_Range]+B_Posi+(Kb2[_B_Range]*(V[B]-B_Posi)+ 512)/1024);
	    a=(Kb1[_B_Range]+B_Posi+(Kb2[_B_Range]*((((DataBuf[TriggerPosition-1]>>8)&0xFF)-ADCoffset)-B_Posi)+ 512)/1024)-_Vt2;        
          }else goto bypasscalculate; 
        }
        Shift=-((((b*102400)/((a+b)*TempKp1))+50)/100);		//calculate jitter from analog channels
      }
bypasscalculate:								   //digital channels		

     if ((i==155)&&(_T_base > 16)&&(_Mode!=SCAN)&&(__Get(FIFO_START)!=0)){	   //calculate jitter position if trig from dig channels
        if((Title[7][1].Value==1)||(Title[7][1].Value==3)||(Title[7][1].Value==4)||(Title[7][1].Value==5)){	//positive transitions
          if (Title[7][0].Value==2){
            for (jj=DTriggerPosition;jj<155;jj++){					
	      if (((DataBuf[jj]>>16)&1)==1){Shift=((jj-DTriggerPosition)*1024)/TempKp1;break;}       
            }		
          }else if(Title[7][0].Value==3){
            for (jj=DTriggerPosition;jj<155;jj++){
	      if (((DataBuf[jj]>>16)&2)==2){Shift=((jj-DTriggerPosition)*1024)/TempKp1;break;}
            }		
          }
        }else{										//negative transitions
          if (Title[7][0].Value==2){										
            for (jj=DTriggerPosition;jj<155;jj++){
	      if (((DataBuf[jj]>>16)&1)==0){Shift=((jj-DTriggerPosition)*1024)/TempKp1;break;}
            }		
          }else if(Title[7][0].Value==3){
            for (jj=DTriggerPosition;jj<155;jj++){
	      if (((DataBuf[jj]>>16)&2)==0){Shift=((jj-DTriggerPosition)*1024)/TempKp1;break;}
            }		
          } 
        }
      }  

      if(i >= k){                          // pointer to reach the specified window position
					   // Use V[x] loaded above rather than unsigned Ch[x], prevents clipping.
	  if (CalFlag>0) {
            Tmp=Ka2[_A_Range]*(V[A]-A_Posi)  ;        // Factor in gain correction for signal (Ka2) from signal zero point
            if (Tmp>0)Tmp+=512; else Tmp-=512;	    // Flip bias if negative, allows proper compensation of negative values
            V[A]  = Ka1[_A_Range]+A_Posi+(Tmp/1024);      
            Tmp=Kb2[_B_Range]*(V[B]-B_Posi);
            if (Tmp>0)Tmp+=512; else Tmp-=512;	   
            V[B]  = Kb1[_B_Range]+B_Posi+(Tmp/1024);     
	  }else{											    
            Tmp=V[A]-A_Posi; 
            V[A]  = Ka1[_A_Range]+V[A];                     // gain correction switched off
            V[B]  = Kb1[_B_Range]+V[B];      
          }


			Tmp=Tmp+Ka1[_A_Range]-_1_posi;
	                Tmp=(Ka2[_A_Range]*Tmp)/1024;  


			Tmp=((VxAvg[0]/NSamples)+Ka1[_A_Range]-_1_posi);
	                Tmp=Ka2[_A_Range]*Tmp;   // Add signal level correction factor based on signal zero level rather than bottom of screen, prevents offsets from corrupting value 
                        if (Tmp>0)Tmp+=512; else Tmp-=512;	 	        	
                        Tmp/=1024;


      if((Det&1)&&(_1_source)){                                 //filter=40
        if(i>=(Filter+28)){
          X=0;
          for(h=(i-Filter);h<i;h++){           
            Tmp=(DataBuf[h] & 0xFF )-ADCoffset;                 //retrieve each of Filter number of samples           
            if(Tmp<0)Tmp=0;                                  
            Tmp=Tmp+Ka1[_A_Range]-_1_posi;
            Tmp=(Ka2[_A_Range]*Tmp)/1024;
            if(Tmp<0)Tmp=-Tmp;                                  //detect
            if(_Kind==4){
              Tmp=((Tmp*225)+50)/100;                             
            }else{  
              Tmp=((Tmp*280)+50)/100;                             
            }
            X+=(Tmp*Tmp);                                       //sum squares
          }
          Y=(Int_sqrt(X/Filter));
          if(Y>198)Y=198;
          Y=(Y*(100+((198-Y)/2)))/100; 
          V[A]=Y;
        }else V[A]=0;
      }

      if((Det&2)&&(_2_source)){
        if(i>=(Filter+28)){
          X=0;
          for(h=(i-Filter);h<i;h++){           
            Tmp=((DataBuf[h] >> 8) & 0xFF)-ADCoffset;                            
            if(Tmp<0)Tmp=0;                                  
            Tmp=Tmp+Kb1[_B_Range]-_2_posi;
            Tmp=(Kb2[_B_Range]*Tmp)/1024;
            if(Tmp<0)Tmp=-Tmp;              
            if(_Kind==4){
              Tmp=((Tmp*225)+50)/100;                             
            }else{  
              Tmp=((Tmp*280)+50)/100;                             
            }
            X+=(Tmp*Tmp);                               
          }
          Y=(Int_sqrt(X/Filter));                                        
          if(Y>198)Y=198;
          Y=(Y*(100+((198-Y)/2)))/100; 
          V[B]=Y;
        }else V[B]=0;
      }

        while(j > 0 ){
          if ((Options&2)&&(_T_base<17)) {   // prevent interpolate routine from interfering with non-interpolated time bases
            Send_Data( V[A_],V[B_],C_D,n++);	  // allows proper display of narrow pulses		
          }else{
            Send_Data( V[A_]+((V[A]-V[A_])*(1024 - j))/1024, // the current CH_A point interpolation
                       V[B_]+((V[B]-V[B_])*(1024 - j))/1024, // the current CH_B point interpolation
                       C_D,                                  // current point digital channel values
                       n++);
          }					
          j -= TempKp1;
          if(n >= X_SIZE){ k = 8192;  break;}    	
        }  

        j += 1024;                              
        V[A_] = V[A];  V[B_] = V[B];            

      }

    }						// end of for loop

    if ((exitflag==1)&&(JumpCnt<(393+Xtend))) exitflag=0;      //if exitflag was on at start, full frame finished allows freerun     

    if ((FrameMode!=0) && (_T_base>11) && (_Mode==SCAN)) __Set(FIFO_CLR, W_PTR);

        if(Options&4){ 	//alarms
          if(_Mode!=X_Y){

                      if(Title[V_VERNIE][V1].Value<200){	//lock out if at extreme top
			h=a_Max-A_Posi;
	                h = (((Ka2[_A_Range]*h)+512)/1024);
                        h=h+_1_posi;	 	        	
                        if((h>Title[V_VERNIE][V1].Value)&&(Title[0][0].Value!=0)&&(Title[V_VERNIE][2].Value==0)) Beeper(500);

			h=b_Max-B_Posi;
	                h = (((Kb2[_B_Range]*h)+512)/1024);
                        h=h+_2_posi;	 	        	
                        if((h>Title[V_VERNIE][V1].Value)&&(Title[1][0].Value!=0)&&(Title[V_VERNIE][2].Value==1))Beeper(500);
                      }

                      if(Title[V_VERNIE][V2].Value>0){	//lock out if at extreme bottom
			h=a_Min-A_Posi;
	                h = (((Ka2[_A_Range]*h)+512)/1024);
                        h=h+_1_posi;	 	        	
                        if((h<Title[V_VERNIE][V2].Value)&&(Title[0][0].Value!=0)&&(Title[V_VERNIE][2].Value==0))Beeper(500);

			h=b_Min-B_Posi;
	                h = (((Kb2[_B_Range]*h)+512)/1024);
                        h=h+_2_posi;	 	        	
                        if((h<Title[V_VERNIE][V2].Value)&&(Title[1][0].Value!=0)&&(Title[V_VERNIE][2].Value==1))Beeper(500);
                      }
          }

        }

  	AWavCenter=(a_Max + a_Min)/2;
        BWavCenter=(b_Max + b_Min)/2;

	if(CurDefTime>0){  		           //allow V cursors to adjust time meters trigger level
  	  h=AWavCenter;
          Tmp=h; 
          h=(((Ka2[_A_Range]*(h-A_Posi))+512)/1024)+_1_posi;
          if(Title[V_VERNIE][V1].Value<h){
            AWavCenter-=(((1024*(h-Title[V_VERNIE][V1].Value))+((512*Ka2[_A_Range])/1024))/Ka2[_A_Range]);
            if(Title[V_VERNIE][V2].Value>Title[V_VERNIE][V1].Value){
              Tmp+=(((1024*(Title[V_VERNIE][V2].Value-h))+((512*Ka2[_A_Range])/1024))/Ka2[_A_Range]);
              AWavCenter=Tmp; 
            }
          }else if(Title[V_VERNIE][V2].Value>h){
            AWavCenter+=(((1024*(Title[V_VERNIE][V2].Value-h))+((512*Ka2[_A_Range])/1024))/Ka2[_A_Range]);
          } 
  	  h=BWavCenter;
          Tmp=h; 
          h=(((Kb2[_B_Range]*(h-B_Posi))+512)/1024)+_2_posi;
          if(Title[V_VERNIE][V1].Value<h){
            BWavCenter-=(((1024*(h-Title[V_VERNIE][V1].Value))+((512*Kb2[_B_Range])/1024))/Kb2[_B_Range]);
            if(Title[V_VERNIE][V2].Value>Title[V_VERNIE][V1].Value){
              Tmp+=(((1024*(Title[V_VERNIE][V2].Value-h))+((512*Kb2[_B_Range])/1024))/Kb2[_B_Range]);
              BWavCenter=Tmp;
            }
          }else if(Title[V_VERNIE][V2].Value>h){
            BWavCenter+=(((1024*(Title[V_VERNIE][V2].Value-h))+((512*Kb2[_B_Range])/1024))/Kb2[_B_Range]);
          }
        }
        a_Mid_H = TimeCalcHyst +AWavCenter;
        a_Mid_L = a_Mid_H - (2*TimeCalcHyst);
        b_Mid_H = TimeCalcHyst +BWavCenter;
        b_Mid_L = b_Mid_H - (2*TimeCalcHyst);

        QEnd[0]=TaS;					//ending sampling positions for quantization error correction 
        QEnd[1]=TbS;

       TaS -= Ta; TbS -= Tb; TcS -= Tc; TdS -= Td;

  if((_Status == RUN)&&(Options&4)&&(ClearHoldFlag>0)){       //clear hold if in fast mode (after first loop)
    if((_T_base > 10)||((_T_base < 11)&&((JumpCnt==get_bag_max_buf())||(freerun==1)))){ //if in slow mode, wait for frame to be done     
     if(SlowModeSkip==0){    
      if(Title[TRIGG][SOURCE].Value<4){   						//if not in ab mode
        ClearMinMax(ClearHoldFlag);
        ClearHold(ClearHoldFlag);
        ClearHoldFlag=0;
      }else{										//in ab mode
         if((TrigSourceEnable==0)&&(ClearHoldFlag&1)){
           ClearMinMax(1);
           ClearHold(1);
           ClearHoldFlag--;								//removes bit 1 (tested as set)
         }
         if((TrigSourceEnable==1)&&(ClearHoldFlag&2)){
           ClearMinMax(2);
           ClearHold(2);
           ClearHoldFlag&=0xFD;								//removes bit 2
         }
      }
     }else if(SlowModeSkip>0) SlowModeSkip--;
    } 
  }    

    if(JumpCnt==get_bag_max_buf())ClearLeadingEdge=0;             //  WAS 0    if turned on by clear screen, reset at end of frame
    if((SumResetFlag==1)&&((JumpCnt==get_bag_max_buf())||(freerun==1)||(_Status!= RUN))){   //in slow mode wait for all necessary loops 
      EnablePaS=1;									    //      	to complete frame
      ResetSum();				//sync sum resets between meter reads and completed frames 
      SumResetFlag=0;
    }

      if (WaitForTrigFlag){                     //meter reset flag for normal modes when not triggered so display retains values while waiting  
        EnablePaS=1;				//while allowing consequent trigger to display values properly					    
        ResetSum();
        WaitForTrigFlag=0;				
      }

        if(a_Max>Ga_Max)Ga_Max=a_Max;		//update peak from all frames into Gx_Max,Min
        if(b_Max>Gb_Max)Gb_Max=b_Max;
        if(a_Min<Ga_Min)Ga_Min=a_Min;
        if(b_Min<Gb_Min)Gb_Min=b_Min;

        if((Options&4)==4){ 			//if in hold mode, transfer to GHx_xxx since Gx gets reset every read or frame interval
          if(a_Max>GHa_Max)GHa_Max=a_Max;else if(HoldResetFlag&1)GHa_Max=a_Max;		//if max is negative, establish start point
          if(b_Max>GHb_Max)GHb_Max=b_Max;else if(HoldResetFlag&2)GHb_Max=b_Max;
          if(a_Min<GHa_Min)GHa_Min=a_Min;else if(HoldResetFlag&1)GHa_Min=a_Min;		//if min is positive, start
          if(b_Min<GHb_Min)GHb_Min=b_Min;else if(HoldResetFlag&2)GHb_Min=b_Min;
          HoldResetFlag=0;
        }else{					//if not in hold mode
          GHa_Max=Ga_Max;
          GHb_Max=Gb_Max;
          GHa_Min=Ga_Min;
          GHb_Min=Gb_Min;
        }


    if((_1_source != HIDE)||(_4_source>13)){
           UTmp= (1000000000/TaS)*TaN;			//Calculate frequency using data from last frame
           UTmp-=QError(0,QStart[0],QEnd[0],UTmp);	//Adjust for any possible quantization error compensation
	   Average(0);					//Include all previous data transfers and average
    }
    if((_2_source != HIDE)||(_4_source==12)||(_4_source==13)){          
           UTmp= (1000000000/TbS)*TbN;		
           UTmp-=QError(1,QStart[1],QEnd[1],UTmp);	
	   Average(1);
    } 	
    if(_3_source == CH_C){         
           UTmp= (1000000000/TcS)*TcN;		
	   Average(2);
    } 	
    if((_4_source == CH_D)||(_4_source == C_and_D)||(_4_source == C_or_D)){
           UTmp = (1000000000/TdS)*TdN;
	   Average(3);
    } 	

   if ((Title[TRIGG][SOURCE].Value>1)&&(Title[TRIGG][SOURCE].Value<4)){	  //if triggering from digital chs, alignment with analog chs shifts waveforms to the right,
     for(h=0; h<=(X_SIZE-5); h++){                     			  //shift back to original position    
      for(i=0;i<4;i++){
        TrackBuff[h*4+i] = TrackBuff[(h+5)*4+i];
      } 
     }
   }

if (_T_base > 16){					//jitter compensation for interpolated modes

  if(Title[TRIGG][SOURCE].Value==4){  			//if in A&B trig mode   

    if(TrigSourceEnable==0){

     if (Shift<0){
      for(h=X_SIZE;h>=-Shift; h--){                   
        TrackBuff[h*4] = TrackBuff[(h+Shift)*4];
      }
     }
     if (OldShift<0){
      for(h=X_SIZE;h>=-OldShift; h--){                   
        TrackBuff[h*4+1] = TrackBuff[(h+OldShift)*4+1];
      }
     }

    }else if(TrigSourceEnable==1){

     if (Shift<0){
      for(h=X_SIZE;h>=-Shift; h--){                   
        TrackBuff[h*4+1] = TrackBuff[(h+Shift)*4+1];
      }
     }
     if (OldShift<0){
      for(h=X_SIZE;h>=-OldShift; h--){                   
        TrackBuff[h*4] = TrackBuff[(h+OldShift)*4];
      }
     } 

    }
    
    Tmp=Shift;
    if(OldShift<Shift)Shift=OldShift;			//for blanking, use the largest neg value of the two
    OldShift=Tmp;

  }else{	//source not AltAB

    if (Shift>0){
      for(h=0; h<=(X_SIZE-Shift); h++){                   
        for(i=0;i<4;i++){
          TrackBuff[h*4+i] = TrackBuff[(h+Shift)*4+i];
        } 
      }
    }else if (Shift<0){
      for(h=X_SIZE;h>=-Shift; h--){                   
        for(i=0;i<4;i++){
          TrackBuff[h*4+i] = TrackBuff[(h+Shift)*4+i];
        } 
      }
    } 

  }   					//else... 

}  					//if Tbase...  

   if (_T_base < 17){			//pre signal blanking						
     if (_T_base > 10){
       discard=4;
     }else discard=1;
     if((_T_base==10)&&(SerialStatus))discard=4;
   }else if (Shift<0){
     discard=-Shift;
   }else discard=0;
   if (_Mode==SGL) discard=4;
							
   if (Shift>0)Rdiscard=Shift;else Rdiscard=0;		    //Shift is >0 when in highest time bases triggered from digital channel 	
   if (_T_base>16)Rdiscard+=7;else Rdiscard=0;              //and is compensated for interpolation

   for(jj=0; jj<discard; jj++){                             // Discard first pixels, fill with next valid sample
    TrackBuff[jj*4] = TrackBuff[discard*4];		    // conditional in draw.c blanks these 	
    TrackBuff[jj*4+1] = TrackBuff[discard*4+1];             // this way it doesn't misalign wave trace with trigger vernier...
   }
   if ((Title[TRIGG][SOURCE].Value<2)||(Title[TRIGG][SOURCE].Value==4))Tmp=6; else Tmp=0;      //add 6 to blank C and D if not shifting screen to the left 5 samples ie:triggering from analog channels

   for(jj=0; jj<(discard+Tmp); jj++){                       // Discard first pixels, fill with next valid sample
    TrackBuff[jj*4+2] = TrackBuff[(discard+Tmp)*4+2];          
   }

   if ((Title[TRIGG][SOURCE].Value<2)||(Title[TRIGG][SOURCE].Value==4)){				
     if ((_4_source==A_add_B)||(_4_source==A_sub_B))Tmp=0;      
   }

   for(jj=0; jj<(discard+Tmp); jj++){                           	
    TrackBuff[jj*4+3] = TrackBuff[(discard+Tmp)*4+3];
   }

    for(h=X_SIZE; h>(X_SIZE-Rdiscard); h--){                  //post signal blanking 
      for(i=0;i<4;i++){
        TrackBuff[h*4+i] = TrackBuff[(X_SIZE-Rdiscard)*4+i];         
      } 
    }


    if(Det){                                                  //center filter output on wave
      for(h=0; h<(X_SIZE-(Filter/2)); h++){                   
        if((Det&1)&&(_1_source)){
          TrackBuff[h*4] = TrackBuff[(h+(Filter/2))*4];
        }
        if((Det&2)&&(_2_source)){
          TrackBuff[h*4+1] = TrackBuff[(h+(Filter/2))*4+1];
        }
      }
      for(h=(X_SIZE-(Filter/2)); h<X_SIZE; h++){                   
        if((Det&1)&&(_1_source))TrackBuff[h*4] = TrackBuff[(h-1)*4];
        if((Det&2)&&(_2_source))TrackBuff[h*4+1] = TrackBuff[(h-1)*4+1];
      }
    } 


	// FFT /////////////////////////////
        u8 treshold=6;
        if(AutoFFT==0)treshold=75;		//log mode, uses high gain

	if(((ShowFFT==1)||(_4_source==SPEC_A))&&(_Mode!=X_Y)&&((EnableFFT==1)||(_T_base>7)||(__Get(FIFO_START)==0)  ||(_Mode==SCAN)  )){
           EnableFFT=2;
	   for(i=0; i<FFTSize;i++)	fi[i] = 0;
	   fix_fft(fr, fi, FFTSize);

           fr[1]=0; 
           fr[0]=0; fi[0]=0;                            					            
	   for (i=0; i < (FFTSize/2); i++)
	     {
		X= fr[i];      /* Real */		
		Y= fi[i];      /* Imag */    
                fi[ i ] = Int_sqrt((X*X)+(Y*Y));	//load in fi[x] instead of fr[x], so result can persist after loading input in fr[x]
                if(fi[i]<0)fi[i]=0;        

                if((_4_source==15)||(_4_source==13)){   //wide bandwidth, sums peak with adjacent bins, so need to leave space before next peak
                  if(i>3){         			//was 5    3 now works with  i>5 on leftskirt conditional and fr[1] cleared 
                    if((fi[i-2]>=fi[i-3])&&(fi[i-2]>fi[i-1])&&(fi[i-2]>treshold)){	        //detect peak (i= -2 =peak), threshold
                      fi[i-2]=Int_sqrt((fi[i-2]*fi[i-2])+(fi[i-3]*fi[i-3])+(fi[i-1]*fi[i-1]));  //sum with neighbors
                      fi[i-3]=2+(fi[i-2]>>2);					      		//suppress left skirt (was >>3 for hamming W)                      
                      LeftSkirt=i-3;						      		//save it's position	 
                    }
                    if(((i-5)==LeftSkirt)&&(i>5)){fi[i-3]=fi[i-5];LeftSkirt=0;}  //suppress right skirt of summed peak if next bin skipped
                  }  

                  if(i>7){
                    fi[i-7]=Log10Process(i-7);          //Processed bins in summing mode
                  } 

                }else{
                    fi[i]=Log10Process(i);               //In Hann only mode
                }
 	     }

             if((_4_source==15)||(_4_source==13)){
                for(i=249;i<256;i++){
                    fi[i]=Log10Process(i);                    //Rest of bins in summing mode
                }
             }
          } 
	//////////////////////////// FFT ///

      if((_T_base<11)&&(JumpCnt>=get_bag_max_buf())){                           
          if(UpdateBackground==3)UpdateBackground=0;                            
            else if(UpdateBackground>0){
              UpdateBackground++;
              if(_T_base<5)UpdateBackground=3;
            }     
      }
      if(_T_base>10)FrameEndFlag=1; 
}


void Send_Data(s16 Va, s16 Vb, u8 C_D, u16 n)  // output display data
{
  s32 Tmp = 0, i;
  u8 Start;
  if((Title[TRIGG][SOURCE].Value>1)&&(Title[TRIGG][SOURCE].Value<4))Start=5;else Start=0;

  i = n*4;

  if(Va >= Y_BASE+Y_SIZE)  TrackBuff[i + TRACK1] = Y_BASE+Y_SIZE-1;
  else if(Va <= Y_BASE+1)  TrackBuff[i + TRACK1] = Y_BASE+1;
  else                     TrackBuff[i + TRACK1] = Va;
  if(Vb >= Y_BASE+Y_SIZE)  TrackBuff[i + TRACK2] = Y_BASE+Y_SIZE-1;
  else if(Vb <= Y_BASE+1)  TrackBuff[i + TRACK2] = Y_BASE+1;
  else                     TrackBuff[i + TRACK2] = Vb;
  
  if(C_D & 1)  TrackBuff[i + TRACK3] = c_Max;
  else         TrackBuff[i + TRACK3] = _3_posi;
  
  switch (_4_source){                       
  case A_add_B:
    Tmp = Posi_412 + Va + Vb;
    break;
  case A_sub_B:
    Tmp = Posi_41_2 + Va - Vb;	
    break;
  case C_and_D:
    //if((~C_D)& 3) Tmp = d_Max;				// was backwards... 
    //else          Tmp = _4_posi;
    if((~C_D)& 3) Tmp = _4_posi; 
    else          Tmp = d_Max;
    break;  
  case C_or_D:
    if(C_D & 3)   Tmp = d_Max; 
    else          Tmp = _4_posi;
    break;  

if(n>=Start){
  case REC_1:
    Tmp = Posi_4F1 + FileBuff[n-Start];  
    break;
  case REC_2:
    Tmp = Posi_4F2 + FileBuff[n+400-Start];  
    break;
  case REC_3:
    Tmp = Posi_4F3 + FileBuff[n+800-Start];  
    break;
  case REC_4:
    Tmp = Posi_4F4 +  FileBuff[n+1200-Start];  
    break;
}

  case (10)...(15):		//fft functions	
    break;
  default:
    if(C_D & 2)  Tmp = d_Max;
    else         Tmp = _4_posi;
  }
  if(Tmp >= Y_BASE+Y_SIZE)  TrackBuff[i + TRACK4] = Y_BASE+Y_SIZE-1;
  else if(Tmp <= Y_BASE+1)  TrackBuff[i + TRACK4] = Y_BASE+1;
  else                      TrackBuff[i + TRACK4] = Tmp;
}
/*******************************************************************************
 Synchro: scan synchronization, waveform display by setting the mode
*******************************************************************************/
void Synchro(void)  // scan synchronization: AUTO, NORM, SGL, NONE, SCAN modes
{ 
freerun=0;
u32 waste=0;

   if(HoldOnNext==1) {
    _State.Value = HOLD;                                    	       // for single mode
    _State.Flag |= UPDAT;
    HoldOnNext=0;
    return;
   }

if (BailoutFlag>0) {BailoutFlag=0; goto BailOut;} 				//if in trigger delay

if (FrameMode>0)								//single frame buffer
 {
  switch (_Mode)
  {  
     case X_Y:
     case AUTO:
        __Set(TRIGG_MODE,(_Tr_source <<3)+TriggerType);  
      if((__Get(FIFO_START)!=0)||(_State.Value==2)){
        if (entryflag>0){
          JumpCnt=0;
          entryflag=0;
        }
        Process();
        Wait_Cnt=shortwait[_T_base];                                              
        exitflag=1;                                                          
      }else if ((Wait_Cnt==1)&&(_T_base < 9)){
        if (_T_base <6)__Set(FIFO_CLR, W_PTR);                              
      }else if(Wait_Cnt ==0){
        if (_T_base > 8){
          freerun=1;
          entryflag=0;
        }else{
          freerun=2;						  
          entryflag=1;                                                 
        }
        if (JumpCnt > (392+Xtend))JumpCnt = 0;                     
        Process();
      }
      break;
    case NORH:                      
    case NORHLD:
      if(Title[TRIGG][SOURCE].Value !=4) __Set(TRIGG_MODE,(_Tr_source <<3)+TriggerType);  
      if((__Get(FIFO_START)!=0)||(_State.Value==2)){                                          //if device triggered or in pause mode
        Process();                                 
        Wait_Cnt=Wait[_T_base];
      }else{
        if(Wait_Cnt==0){
          Wait_Cnt = 1;
        }
      }
      break;
    case NORC:					
     __Set(TRIGG_MODE,(_Tr_source <<3)+TriggerType);  
      if((__Get(FIFO_START)!=0)||(_State.Value==2)){
          Process();
          Wait_Cnt=Wait[_T_base];
        } else if(Wait_Cnt==0)						//was ==1
         {
          ResetSum();	                      
          if (_T_base < 7) cleardatabuf(2);
          ClearTrackBuff(0);
          Wait_Cnt=Wait[_T_base];						//added
      }
      break;
   case SGL:					
      __Set(TRIGG_MODE,(_Tr_source <<3)+TriggerType);  
      if((__Get(FIFO_START)!=0)||(_State.Value==2))  Process();         
      break;
    case SCAN:								
      if (_T_base>11){ 
        __Set(TRIGG_MODE, UNCONDITION);            	// works best at high sweep rates
      }else{                                          // works better at low rates
       __Set(TRIGG_MODE,3);  		                  // same as track1 (0) <<3 + 3 (>vt) (do not use digital chs...) 
       __Set(V_THRESHOLD,255);                        // level then set out of range. Prevents triggering(vt>255), with fifo "splice" shifted left 150pix, gives smooth display at low speeds
      }
      if (_T_base>7){ 
        freerun=1;
        Process();                                  	
      }else{ 								//tbase<8
         freerun=2;
         if ((FlagMeter==0) && (JumpCnt> 389)) JumpCnt=0;
         if ((FlagMeter>0) && (JumpCnt> 304)) JumpCnt=0;
         Process();
      } 
   } //switch
 }
 else										//regular large buffer mode
 {
 switch (_Mode)
   { 
   case X_Y:
   case AUTO:
       __Set(TRIGG_MODE,(_Tr_source <<3)+TriggerType);  
      if((__Get(FIFO_START)!=0)||(_State.Value==2)){
        Process();                                 
        Wait_Cnt = Wait[_T_base];
      } else if(Wait_Cnt==0) {
          if(_Mode==X_Y){if(JumpCnt>=BufferSize)JumpCnt = 0;
          }else{if(JumpCnt >= 4095)  JumpCnt = 0;} 
          Process();   
          Wait_Cnt = Wait[_T_base];
      } break;
    case NORH:
    case NORHLD:
      if(Title[TRIGG][SOURCE].Value !=4) __Set(TRIGG_MODE,(_Tr_source <<3)+TriggerType);  
      if((__Get(FIFO_START)!=0)||(_State.Value==2)){
        Process();                                 
        Wait_Cnt = Wait[_T_base];
      } else if(Wait_Cnt==0) {
       Wait_Cnt = Wait[_T_base];
      } break;
     case NORC:
      __Set(TRIGG_MODE,(_Tr_source <<3)+TriggerType);  
      if((__Get(FIFO_START)!=0)||(_State.Value==2)){
        Process();                                 
        Wait_Cnt = Wait[_T_base];
      } else if(Wait_Cnt==0) {
       ResetSum();	                      
       ClearTrackBuff(0);		      // clear screen
        Wait_Cnt = Wait[_T_base];
      } break;
   case SGL:
      __Set(TRIGG_MODE,(_Tr_source <<3)+TriggerType);  
      if((__Get(FIFO_START)!=0)||(_State.Value==2))  Process();         
	break;
    case SCAN:								
      if (_T_base>11){ 
        __Set(TRIGG_MODE, UNCONDITION);               	
      }else{
       __Set(TRIGG_MODE,3);  
       __Set(V_THRESHOLD,255); 
      }
      if (_T_base>7){ 
        freerun=1;
        Process();                                  
      }else{ 						 //tbase<8
         freerun=2;
         if(JumpCnt >= 4095)  JumpCnt = 0; 
         Process();
       } 
   }  										
 }   							 // end else (framemode=0)

  if (_Mode==SCAN) Wait_Cnt = 1;	     	

  if(_Mode==X_Y){
    if(JumpCnt>=BufferSize){
      JumpCnt = 0;
      __Set(FIFO_CLR, W_PTR);
      FrameEndFlag=1;
    }
  }

  if ((FrameMode > 0)&&(_Mode!=SGL)){                    // in single frame buffer mode
    if (_Mode==SCAN){
      if ((FlagMeter==0) && (JumpCnt> 389)) JumpCnt=0;
      if ((FlagMeter>0) && (JumpCnt> 304)) JumpCnt=0;
    } 
    if (JumpCnt>(392+Xtend)){
      if((__Get(FIFO_START)!=0)&&(freerun!=2)){          // resetting FIFO after start flag and frame completed provides proper triggering in single frame buffer mode

        FrameEndFlag=1;
           
        JumpCnt=0;
        if ((Options&1)&&(_T_base < 10)&&(_Mode!=AUTO)&&(_Mode!=X_Y)&&(_Mode!=SGL)&&(_Mode!=SCAN)){	//trigger hold mode, works only with time bases where process is slower than data transfers
          CountUnread=0;
BailOut:
          if (Title[7][3].Value>0){				       //add additional adjustable delay just before resetting write pointer

            DelayLoopBreak=50;				//restrict max time in loop to 1 sec to prevent possible lockup with empty buffer
            while (CountUnread<Title[7][3].Value){

              if (__Get(FIFO_EMPTY)==0){		//if FIFO has data to read
                waste =__Read_FIFO();			//FIFO reads provide relative timing for delay
                CountUnread++;
              }else{					//while loop can lockup with empty buffer          
                if(Update>1)break;			//when initiating, drop out to reset FIFO
                if(DelayLoopBreak==0)break;      	//interrupt based breakout after 1 sec if necessary           
              }
              if ((CountUnread>0)&&((CountUnread%(TrigDelayLoop[_T_base]))==0)){    //Allow program to operate on a time base related interval while counting delay
                BailoutFlag=1;							    	
                break;
              }
            } 

          }  //if Title... (trig hold value > 0)
        }    //if options... (set trigger hold mode)

        if (BailoutFlag==0){

	    if (Title[TRIGG][SOURCE].Value==4){AlternateChannel();AltHoldoff=AltDelay[_T_base];}
            __Set(FIFO_CLR, W_PTR);			

        }

        waste++;			//compiler needs to do something with this or generates error... (used to read FIFO)
      }          //if get fifo start
    }            //if jumpcnt>
  } 		 //if framemode>0

  if((_Status == RUN)&&((_T_base > 10)||((_T_base>9)&&(Tim2Factor>20)))&&(_T_base < 14)&&(_Mode != SGL)){  	    				
    if ((__Get(FIFO_START)!=0)&&(FrameMode >0))	{				    //prevents "double looping" in single window buffer mode
        if ((Title[TRIGG][SOURCE].Value==4)&&(_Status == RUN)) AlternateChannel();  //causing problems in 50, 100, and 200uS/div ranges
        __Set(FIFO_CLR, W_PTR);	 					  
    }          								  		
  }

  if ((_Status == RUN)&&(__Get(FIFO_FULL)!=0))  {                        // FIFO is full 

    if(_Mode != SGL) {
      if (Title[TRIGG][SOURCE].Value==4){
        AlternateChannel();
        if(_T_base < 10)AltHoldoff=AltDelay[_T_base];
      } 
      __Set(FIFO_CLR, W_PTR);   //if mode is not single                                         // FIFO write pointer reset

    }else if(_T_base < 11){	                                        //in SGL mode, added reset after moving to slow mode
      __Set(FIFO_CLR, W_PTR);                                           //also added reset JumpCnt on hold/run reset 
    }

    if(_Mode!=X_Y){
      if (FrameMode == 0){Wait_Cnt = Wait[_T_base];FrameEndFlag=1;}
      JumpCnt =0;
    } 

    if(_Mode == SGL){
      HoldOnNext=1;
    }
  }

  if ((_Mode != AUTO)||(_T_base > 8)||(exitflag==0)||(entryflag==0)) Draw_Window(); //Executing time consuming screen update AFTER resetting FIFO rather than before
                                                                                    //allows enough time for START flag to register at fast time bases - fixes triggering
										    //issue of slow/random pulses not triggering

  if ((_Status == RUN)&&(__Get(FIFO_START)==0)&&(Title[TRIGG][SOURCE].Value==4)){   //alternate channels after delay if selected ch not triggered	
     if(_T_base > 9){
         cleardatabuf(TrigSourceEnable);
         AlternateChannel();
         __Set(FIFO_CLR, W_PTR);
     }else{
       if(AltHoldoff==0){
         AltHoldoff=AltDelay[_T_base];
         cleardatabuf(TrigSourceEnable);
         AlternateChannel();
         __Set(FIFO_CLR, W_PTR);
       }
       if(AltHoldoff>0)AltHoldoff--;
     }
  }

}   										               

u16 get_bag_max_buf(void) {
u16 out = 4096;

  if ((FrameMode>0)&&(_Mode!=SGL)){
    if (_Mode==SCAN){					
        if (FlagMeter==0)out=390; else out=305;
        if (_4_source>9)out=512;            //for FFT
        if (_T_base>9) out=390+150;	    //moves trigger splice out of view to left edge of screen at fast time bases for cleaner display
    }else{	
        out =  (393+Xtend);		    //modify buffer size if meters are on or off or XPOS shifted
    }
  }else if(_Mode==X_Y)out=BufferSize;
  return out;
}	

void Beeper(u16 ms){
  if(Beep_mS<20) __Set(BEEP_VOLUME, 5*(Title[VOLUME][CLASS].Value-1)); //don't call beeper if currently beeping, seems to shut it off...
  Beep_mS = ms;
}

void AlternateChannel(void){
      	      if(TrigSourceEnable==1)TrigSourceEnable=0; else TrigSourceEnable=1;		     //cycle to next channel
	
	      if(TrigSourceEnable==0){								     //set up ch if enabled	
                if(Title[0][0].Value==0){							     //otherwise skip to next ch	
                  TrigSourceEnable=1;
                }else{
                  ReverseBitMask=0xFFFFFF00;
                  BitMask=0xFF;
                }    
              }
	      if(TrigSourceEnable==1){
                if(Title[1][0].Value==0){
                  TrigSourceEnable=0;
                }else{
                   ReverseBitMask= 0xFFFF00FF;
                  BitMask=0xFF00;	
                }    
              }

              Update_Trig(0);			
}


void cleardatabuf(u8 service)   //Clears/replaces n samples in DataBuf
{
						   
 u32 sample=(B_Posi+ADCoffset);		
 u16 i;

  sample <<= 8;

  if(service==0){
    sample=(A_Posi+ADCoffset); 		
    for (i=0; i<bag_max_buf; i++){
      DataBuf[i]&=0xFFFFFF00;      
      DataBuf[i]|=sample;
    }
  }

  if(service==1){
    for (i=0; i<bag_max_buf; i++){
      DataBuf[i]&=0xFFFF00FF;      
      DataBuf[i]|=sample;
    }
  }

  if(service==2){
    sample|=(A_Posi+ADCoffset);			
    for (i=0; i<bag_max_buf; i++) DataBuf[i]=sample;      
  } 
}

void TransferFIFO(s16 i,u8 service){
  u32 swap;
	    if(service){
              DataBuf[i] &= ReverseBitMask;		//preserve previous data on alternate channel
              DataBuf[i] |= (__Read_FIFO() & BitMask);	//only load triggering channel if in alternate mode
	    } else DataBuf[i] = __Read_FIFO(); 		//normal mode

            if((TrigSourceEnable==1)||(service==0)){    //only swap bits if loading chB 
	      swap=0x300;
	      swap &= DataBuf[i];
	      if ((swap==0x100)||(swap==0x200))DataBuf[i]^=0x300; //swap 2 least significant bits of chB, fixes error in FPGA programming (V2.61)
            }
}

void SetOffset(u8 channel,u8 range, s16 Ypos) {
s32 temp;

      if(channel==0)temp=Ka3[range];else temp=Kb3[range];
      temp=(1024+temp)*(Ypos-ScalingOffset);			               //set Ka3 zero axis, allows scaling optimisation
      if(temp>0)temp+=512; else temp-=512;
      temp=(temp/1024)+ADCoffset+ScalingOffset;
      if (temp<0)temp=0;						       //should not go anywhere close to 0 but just to make sure
      if(channel==0)__Set(CH_A_OFFSET, temp); else __Set(CH_B_OFFSET, temp);
}

void BatLevelCompensation(void){
u8 i;								//make sure both sets are available or don't use

 if((LoBatLevel[0]>2800)&&(LoBatLevel[0]<5200)&&(HiBatLevel[0]>2800)&&(HiBatLevel[0]<5200)){  	         		
  for(i=0;i<10;i++){
    Ka1[i]=InterpolateS8(0,LKa1[i],HKa1[i]);
    Ka2[i]=InterpolateU16(0,LKa2[i],HKa2[i]);
    Ka3[i]=InterpolateS8(0,LKa3[i],HKa3[i]);
  }
 }

 if((LoBatLevel[1]>2800)&&(LoBatLevel[1]<5200)&&(HiBatLevel[1]>2800)&&(HiBatLevel[1]<5200)){	         		
  for(i=0;i<10;i++){
    Kb1[i]=InterpolateS8(1,LKb1[i],HKb1[i]);
    Kb2[i]=InterpolateU16(1,LKb2[i],HKb2[i]);
    Kb3[i]=InterpolateS8(1,LKb3[i],HKb3[i]);
  }
 } 
}


s8 InterpolateS8(u8 Ch, s8 L8,s8 H8){
s32 Tmp;
  Tmp=((__Get(V_BATTERY)-LoBatLevel[Ch])*(H8-L8));
  if(Tmp>0)Tmp+=(VDiff[Ch]/2); else Tmp-=(VDiff[Ch]/2);
  return (Tmp/VDiff[Ch])+L8;
}

u16 InterpolateU16(u8 Ch, u16 L16,u16 H16){
s32 Tmp;
  Tmp=((__Get(V_BATTERY)-LoBatLevel[Ch])*(H16-L16));
  if(Tmp>0)Tmp+=(VDiff[Ch]/2); else Tmp-=(VDiff[Ch]/2);
  return (Tmp/VDiff[Ch])+L16;
}

s32 QError(u8 Ch, u16 Start, u16 End, u32 Utmp){	
s32 b,ab,tmp=0;
		//quantization error compensation; improves accuracy of frequency/period meters on analog channels

     b=(QParam(Ch,Start,1)*(QParam(Ch,End,0)+QParam(Ch,End,1)))-(QParam(Ch,End,1)*(QParam(Ch,Start,0)+QParam(Ch,Start,1)));
     ab=(QParam(Ch,Start,0)+QParam(Ch,Start,1))*(QParam(Ch,End,0)+QParam(Ch,End,1));
     tmp=Utmp/ab;
     tmp=tmp*b;
     if(Ch==0)tmp=tmp/TaS; else tmp=tmp/TbS;
     return tmp;

}

s16 QParam(u8 Ch, u16 Position,u8 service){	

          if(service){								//"b"								
            if(Ch==0){ 
              return ((DataBuf[Position]& 0xFF)-ADCoffset)-LastA_Mid;
            }else{
              return (((DataBuf[Position]>>8)&0xFF)-ADCoffset)-LastB_Mid;
            }
          }else{								//"a"
            if(Ch==0){ 
	      return FirstA_Mid-((DataBuf[Position-1]& 0xFF)-ADCoffset);        
            }else{
	      return FirstB_Mid-(((DataBuf[Position-1]>>8)&0xFF)-ADCoffset);        
            }
          }

}

void Average(u8 Ch){

              //sum averaging of all FIFO transfers; improves resolution/accuracy of all meters at faster timebases (>~5mS/div)

           if((_T_base > 10)||((JumpCnt==get_bag_max_buf())&&(_T_base>6)&&(FrameMode>0))){
             RunAvg(Ch);				//time/freq parameters
             if(Ch==0){					//voltage values
               VxAvg[0]=VRunAvg(0,a_Avg,VxAvg[0]);
               VNAvg[0]--;				//reset VN counters to do SSQ
               VxSsq[0]=VRunAvg(0,a_Ssq,VxSsq[0]);
             }else if(Ch==1){
               VxAvg[1]=VRunAvg(1,b_Avg,VxAvg[1]);
               VNAvg[1]--;
               VxSsq[1]=VRunAvg(1,b_Ssq,VxSsq[1]);
             }

             switch(Ch){				//summing for TH, TL, %duty
             case 0:
               PxS[Ch]+=PaS;             
               TxS[Ch]+=TaS;             
               TxN[Ch]+=TaN;             
               break;
             case 1:
               PxS[Ch]+=PbS;             
               TxS[Ch]+=TbS;             
               TxN[Ch]+=TbN;             
               break;
             case 2:
               PxS[Ch]+=PcS;             
               TxS[Ch]+=TcS;             
               TxN[Ch]+=TcN;             
               break;
             case 3:
               PxS[Ch]+=PdS;             
               TxS[Ch]+=TdS;             
               TxN[Ch]+=TdN;             
             }
           }else{
             Sum[Ch]=UTmp; 				//if frame rates slower than meter reads no summing possible

             switch(Ch){
             case 0:
               VxAvg[Ch]=a_Avg;
               VxSsq[Ch]=a_Ssq;
               PxS[Ch]=PaS;             
               TxS[Ch]=TaS;             
               TxN[Ch]=TaN;             
               break;
             case 1:
               VxAvg[Ch]=b_Avg;
               VxSsq[Ch]=b_Ssq;
               PxS[Ch]=PbS;             
               TxS[Ch]=TbS;             
               TxN[Ch]=TbN;             
               break;
             case 2:
               PxS[Ch]=PcS;             
               TxS[Ch]=TcS;             
               TxN[Ch]=TcN;             
               break;
             case 3:
               PxS[Ch]=PdS;             
               TxS[Ch]=TdS;             
               TxN[Ch]=TdN;             
             }
           }
}

s32 VRunAvg(u8 Ch, s32 Value, s32 Sum){ 		//running average of voltage values
       if(Value>Sum){
         Sum+=((Value-Sum)/++VNAvg[Ch]);
       }else if(Sum>Value){
         Sum-=((Sum-Value)/++VNAvg[Ch]);
       }else VNAvg[Ch]++;
       return Sum; 
}

void RunAvg(u8 Ch){
   if(UTmp>Sum[Ch]){					//moving sum average for frequency/period
     Sum[Ch]+=((UTmp-Sum[Ch])/++NAvg[Ch]);
   }else if(Sum[Ch]>UTmp){				
     Sum[Ch]-=((Sum[Ch]-UTmp)/++NAvg[Ch]);
   }else NAvg[Ch]++;         
}


void ResetSum(void){
u8 Ch;
        for(Ch=0;Ch<4;Ch++){ 
          Sum[Ch]=0;
          NAvg[Ch]=0;
        }

        if(EnablePaS){				//only reset after read, 1/second for TH,TL,%duty in large meters
          for(Ch=0;Ch<4;Ch++){ 
            PxS[Ch]=0;             
            TxS[Ch]=0;             
            TxN[Ch]=0;             
          }

        }
        VxAvg[0]=A_Posi*NSamples;
        VxAvg[1]=B_Posi*NSamples;
        for(Ch=0;Ch<2;Ch++){ 
          VxSsq[Ch]=NSamples/2;
          VNAvg[Ch]=0; 
          ClearMinMax(Ch+1);
        }

}

void ClearMinMax(u8 Channels){
  if(Channels&1){Ga_Max=(-0x7FFF);Ga_Min=0x7FFF;}       
  if(Channels&2){Gb_Max=(-0x7FFF);Gb_Min=0x7FFF;}
  if((Options&4)==0){					//if hold mode is not set, reset GHx as this is used to transfer max and min values
    ClearHold(3);
  }       
}

void ClearHold(u8 Channels){
  HoldResetFlag=Channels;
  if(Channels&1){GHa_Max=A_Posi;GHa_Min=A_Posi;}       
  if(Channels&2){GHb_Max=B_Posi;GHb_Min=B_Posi;}       
}

void ClearTrackBuff(u8 service){
u16 i;
  if(service)ClearLeadingEdge=1; else ClearLeadingEdge=0;             
  for(i=0; i<X_SIZE*4; i++)TrackBuff[i]=0;                   
}

s32 Log10Process(u16 i){
u8 Charact=0;           
s32 n=fi[i];
          if(AutoFFT==0){				//log scaling
            if(n==10)n=5;else{				//special case, would return 0 otherwise because of break in dual scale mant[]
              while (n>99){ 
                n/=10;
                Charact++;
              }
              n=((50*((Charact*100)+Log10Mant[n]))+50)/100; 
            }
          } 
          if(n>198)n=198;   	                        
          if(AutoFFT>0)n=(n*(100+((198-n)/2)))/100;    //2:1 compression, used for regular scaling
          return n;
}

void WaveGen(void){
u16 i;
u16 j=0;
u16 YShift=0;

  if(_Kind==SINE)YShift=4095;

  if(_Kind==SAW){
    for(i=0;i<(720/ScaleIndex[_Frqn]);i++)                                                      
      ATT_DATA[i]=(((Title[OUTPUT][OUTATT].Value*WaveValue(j+=ScaleIndex[_Frqn]))/100)+2048);
  }else if(_Kind==DIGI){
    for(i=0;i<(720/ScaleIndex[_Frqn]);i++) 
      ATT_DATA[i]=(((Title[OUTPUT][OUTATT].Value*DIGI_DATA[(i/(360/ScaleIndex[_Frqn]))])/100)+2048);
  }else if(_Kind==7){
    return;
  }else{
    if(_Frqn<15){ 
      for(i=0;i<(720/ScaleIndex[_Frqn]);i++){                                                      
        if(i<(180/ScaleIndex[_Frqn]))ATT_DATA[i]=(((Title[OUTPUT][OUTATT].Value*WaveValue(j+=ScaleIndex[_Frqn]))/100)+2048);
          else if(i<(360/ScaleIndex[_Frqn]))ATT_DATA[i]=(((Title[OUTPUT][OUTATT].Value*WaveValue(j-=ScaleIndex[_Frqn]))/100)+2048);
            else if(i<(540/ScaleIndex[_Frqn]))ATT_DATA[i]=YShift-(((Title[OUTPUT][OUTATT].Value*(WaveValue(j+=ScaleIndex[_Frqn]))/100)+2048));
              else ATT_DATA[i]=YShift-(((Title[OUTPUT][OUTATT].Value*(WaveValue(j-=ScaleIndex[_Frqn]))/100)+2048));
      }

    }else if(_Frqn==15){

      if(_Kind==SINE){
        for(i=0;i<18;i++){
          ATT_DATA[i]=((Title[OUTPUT][OUTATT].Value*(Sine100K[i]-2048))/100)+2048;
        } 
      }
      if(_Kind==TRIANG){
        for(i=0;i<18;i++){
          ATT_DATA[i]=((Title[OUTPUT][OUTATT].Value*(Triangle100K[i]-2048))/100)+2048;
        } 
      }
    }else{
      if(_Kind==SINE){
        for(i=0;i<9;i++){
          ATT_DATA[i]=((Title[OUTPUT][OUTATT].Value*(Sine200K[i]-2048))/100)+2048;
        } 
      }
      if(_Kind==TRIANG){
        for(i=0;i<9;i++){
          ATT_DATA[i]=((Title[OUTPUT][OUTATT].Value*(Triangle200K[i]-2048))/100)+2048;
        } 
      }

    }
  }
}


s16 WaveValue(u16 j){
    if(_Kind==SINE) return (SIN_QUAD[j]-2048);
      else if(_Kind==TRIANG)return (((11372*j)+500)/1000);
        else if(_Kind==SAW)return (((5686*j)+500)/1000)-2048;     
          else return 0;
}


void InitiateCalData(void){
u8 i;

  for(i=0;i<10;i++){

    Ka1[i] = Kb1[i] = Ka3[i] = Kb3[i] = 0;
    Ka2[i] = Kb2[i] = 1024;

    HKa1[i] = HKb1[i] = HKa3[i] = HKb3[i] = 0;
    HKa2[i] = HKb2[i] = 1024;

    LKa1[i] = LKb1[i] = LKa3[i] = LKb3[i] = 0;
    LKa2[i] = LKb2[i] = 1024;
  }

}


u16 RandomGen(void){      //random number gen to dynamically seed noise generator
static u32 Tmp=1746698375;
  Tmp=((u32)1664525*Tmp)+(u32)1013904223;
  Tmp>>=20;
  return Tmp&0x00000FFF;
}

u8 TriggerModeLogic(void){  
  return(((Title[7][1].Value>3)&&(Title[7][1].Value<8))||(_T_base>18)||((Sweep>0)&&(_Kind<5)&&(Title[7][1].Value==8)));
}

void ClearMeters(void){
            if(((_Mode==NORH)||(_Mode==NORHLD))&&(__Get(FIFO_START)==0)){
              EnablePaS=1;
              ResetSum();
            }             
}


/******************************** END OF FILE *********************************/




