/********************* (C) COPYRIGHT 2010 e-Design Co.,Ltd. ********************
 File Name : File.c  
 Version   : DS203_APP Ver 2.5x                                  Author : bure
*******************************************************************************/
#include <string.h>
#include "Function.h"
#include "Process.h"
#include "BIOS.h"
#include "File.h"
#include "Menu.h"
#include "Calibrat.h"

u16 SectorSize = 0;
u8 flash_mode = 0;
u8  SecBuff[LARGEST_SECTOR_SIZE];
uc8 DiskDevInfo_8M[]={"8MB Internal"};

void Print_Clk(u8 Phase);
u8  SaveShortBuffXpos;
u8  FileBuff[1600];
u16 TempPar[66];
u8  Versions;
const char Clk[4][2]={"|","/","-","$"};

uc16 BMP_Color[16] = { WHT,  CYAN, CYAN_,  YEL,  YEL_, PURPL, PURPL_, GRN,   		//for 16 color BMP's
                      GRN_, GRAY, ORANGE, BLUE, RED,  BLACK, BLACK,  BLACK};    

						      //16 color BMP file header	
uc8  BmpHead16[54] = { 0X42, 0X4D, 0XF8, 0XBB, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X76, 0X0, 0X00, 0X00, 0X28, 0X00,	
                      0X00, 0X00, 0X90, 0X01, 0X00, 0X00, 0XF0, 0X00, 0X00, 0X00, 0X01, 0X0, 0X04, 0X00, 0X00, 0X00,
                      0X00, 0X00, 0X82, 0XBB, 0X00, 0X00, 0X12, 0X0B, 0X00, 0X00, 0X12, 0XB, 0X00, 0X00, 0X10, 0X00,
                      0X00, 0X00, 0X00, 0X00, 0X00, 0X00};
                                                                                             //byte 28= 0x04 bits/pixel
                                                       //64K color BMP file header 
uc8  BmpHead64[66] =  { 0X42, 0X4D, 0X42, 0XEE, 0X02, 0X00, 0X00, 0X00, 0X00, 0X00, 0X42, 0X0, 0X00, 0X00, 0X28, 0X00,	
                      0X00, 0X00, 0X90, 0X01, 0X00, 0X00, 0XF0, 0X00, 0X00, 0X00, 0X01, 0X0, 0X10, 0X00, 0X03, 0X00,
                      0X00, 0X00, 0X00, 0XEE, 0X02, 0X00, 0X12, 0X0B, 0X00, 0X00, 0X12, 0XB, 0X00, 0X00, 0X00, 0X00,
                      0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X1F, 0X00, 0X00, 0X00, 0XE0, 0X07,0X00, 0X00, 0X00, 0XF8,
                      0X00, 0X00};
                                                                                             //byte 28= 0x10 bits/pixel 

/*******************************************************************************
Initialize the file system		return value: 0x00 = successful
Primarily sets variables for flash_mode and SectorSize
*******************************************************************************/
u8 InitFileSystem() {
  u32 ptr;
  u8 Ver[8];
  
  if (SectorSize!=0) return 0;
	
  ptr=__Get(DFUVER);
  memcpy(Ver,(u8*)ptr,5);
  ptr=(Ver[1]-'0')*100 +(Ver[3]-'0')*10 +(Ver[4]-'0'); 
  if(ptr<=311){
    flash_mode=FLASH_2M;
	SectorSize = FLASH_2M_SECTOR_SIZE;
  }
  else{
    ptr=__Get(DEVICEINFO);
    if(memcmp((u8*)ptr,DiskDevInfo_8M,3)==0){
		flash_mode=FLASH_8M;
		SectorSize = FLASH_8M_SECTOR_SIZE;
	}
    else {
		flash_mode=FLASH_2M;
		SectorSize = FLASH_2M_SECTOR_SIZE;
	}
  }  
  if (SectorSize>LARGEST_SECTOR_SIZE) { //This should never happen
	SectorSize = 0;
	return 255;
  }
  return 0;
 }


/*******************************************************************************
 Print_Clk:  progress indicator
*******************************************************************************/
void Print_Clk(u8 Phase)
{
  Print_Str(250,0,0x0405,INV,(char*)Clk[Phase]); 
}

/*******************************************************************************
Open the specified file extension		input: The file extension		return value: 0x00 = successful
*******************************************************************************/
u8 Make_Filename(u8 FileNum, char* FileName)
{
  char Num[4];
  
  u8ToDec3(Num, FileNum,0);
  FileName[4]  = Num[0];
  FileName[5]  = Num[1];
  FileName[6]  = Num[2];
  return InitFileSystem();
} 
/*******************************************************************************
Obtained corresponds to the current color palette number
*******************************************************************************/
u8 Color_Num(u16 Color)			//for 16 color BMP's
{
  if(Color == WHT)                   return 0;
  else if(Color== CYAN  ) return 1;
  else if(Color== YEL   ) return 3;
  else if(Color== PURPL ) return 5;
  else if(Color== GRN   ) return 7;
  else if(Color== CYAN_ ) return 2;
  else if(Color== YEL_  ) return 4;
  else if(Color== PURPL_) return 6;
  else if(Color== GRN_  ) return 8;
  else if(Color== GRAY  ) return 9;
  else if(Color== ORANGE) return 10;
  else if(Color== BLUE  ) return 11;
  else if(Color== RED   ) return 12;
  //else                              return 13;
  else if(Color== BLACK ) return 13;                             //add black as viable color
  else                    return 9;                              //anything else would be grid background
}
/*******************************************************************************
Load_Dat: Load the saved screen image of the original data		input: The file number		return value: 0x00 = successful
*******************************************************************************/
u8 Load_Dat(u8 FileNum)
{
  char Filename[12] = "FILE    DAT"; 
  u16 i;
  u16 pCluster[3];
  u32 pDirAddr[1]; 
  
  if (Make_Filename(FileNum, Filename)!=0) return 1;
        i = __OpenFileRd(SecBuff, Filename, pCluster, pDirAddr);
        if(i != OK) return i;

	  if(flash_mode==FLASH_2M){
		for(i=0; i<4; i++){
		  if(__ReadFileSec(SecBuff, pCluster)!= OK) return RD_ERR;
		  memcpy(&FileBuff[i*400], SecBuff,400);
		}
	  }
	  else{
		if(__ReadFileSec(SecBuff, pCluster)!= OK) return RD_ERR;
		for(i=0; i<4; i++)
		  memcpy(&FileBuff[i*400], &SecBuff[i*512],400);
	  }

  return 0;
}
/*******************************************************************************
Save_Dat: save current screen to display the original image data		input: the file number		return value: 0x00 = success
*******************************************************************************/
u8 Save_Dat(u8 FileNum)
{
  char Filename[13] = "FILE    DAT"; 
  u16 i, j;
  u16 pCluster[3];
  u32 pDirAddr[1]; 
  
  if (Make_Filename(FileNum, Filename)!=0) return 1;
  if(__OpenFileWr(SecBuff, Filename, pCluster, pDirAddr)!=OK) return DISK_ERR;

    memset(SecBuff, 0, LARGEST_SECTOR_SIZE);//512

	  if(flash_mode==FLASH_8M){
		for(j=0; j<4; j++){
		  for(i=0; i<399; i++) SecBuff[i+j*512] = TrackBuff[i*4 + j];
		  SecBuff[399+j*512] = Title[j][POSI].Value;
		}  
		if(__ProgFileSec(SecBuff, pCluster)!= OK) return WR_ERR; // write data
                Print_Clk(j & 3);              // progress indication
	  }
	  else
	  {
		for(j=0; j<4; j++){
		  for(i=0; i<399; i++) SecBuff[i]= TrackBuff[i*4 + j];
		  SecBuff[399] = Title[j][POSI].Value;
		  if(__ProgFileSec(SecBuff, pCluster)!= OK) return WR_ERR; // write data
                  Print_Clk(j & 3);              // progress indication
		}
	  }

  if(__CloseFile(SecBuff, 0x0800, pCluster, pDirAddr)!= OK) return WR_ERR;
  return OK;
}
/*******************************************************************************
Save_Bmp: save the current screen image as BMP		input: file number		return value: 0x00 = successful
*******************************************************************************/
u8 Save_Bmp(u8 FileNum)
{
  u32 FileSize;
  char Filename[12] = "IMAG    BMP"; 
  u16 k, i,x=0, y=0, j, ColorH, ColorL; //, tmp;        // j,  ColorH, ColorL;
  register u16 tmp;
  u16 pCluster[3];
  u32 pDirAddr[1]; 

  if (Make_Filename(FileNum, Filename)!=0) return 1;
  if(__OpenFileWr(SecBuff, Filename, pCluster, pDirAddr)!=OK) return DISK_ERR;

if((_4_source==10)||(_4_source==11)){					//only save in 64K color if displaying spectrograph or map
  memcpy(SecBuff, BmpHead64, 66);					//64K COLOR BMP
  i = 0x0042; // the image data stored address
  k = 0;
  for(y=0; y<240; y++){
    for(x=0; x<400 ; x++){
      __Point_SCR(x, y);
      tmp =__LCD_GetPixl();
      SecBuff[i++]=tmp&0xFF; SecBuff[i++]=tmp>>8;
      if(i>=SectorSize){ //512
        if(__ProgFileSec(SecBuff, pCluster)!= OK) return WR_ERR; // write data
        Print_Clk((k++ >>1)& 3);    // progress indicator
        i=0; 
      }
    }
  }
  FileSize=0x2F000;
}else{
  memcpy(SecBuff, BmpHead16, 54);					//16 COLOR BMP
  i = 0x0036; // palette to store the starting address
  for(j=0; j<16; ++j){
    SecBuff[j*4 +i+0]=(BMP_Color[j]& 0xF800)>>8; // Blue
    SecBuff[j*4 +i+1]=(BMP_Color[j]& 0x07E0)>>3; // Green
    SecBuff[j*4 +i+2]=(BMP_Color[j]& 0x001F)<<3; // Red
    SecBuff[j*4 +i+3]= 0;                        // Alpha
  }
  i = 0x0076; // the image data stored address
  k = 0;
  for(y=0; y<240; y++){
    for(x=0; x<400 ; x+=2){
      __Point_SCR(x, y);
      ColorH =__LCD_GetPixl();
      __Point_SCR(x+1, y);
      ColorL =__LCD_GetPixl();
      SecBuff[i] =(Color_Num(ColorH)<<4)+ Color_Num(ColorL);
      i++;
      if(i>=SectorSize){
        if(__ProgFileSec(SecBuff, pCluster)!= OK) return WR_ERR; // write data
        Print_Clk((k++ >>1)& 3);    // progress indicator
        i=0; 
      }
    }
  }
  FileSize=0xBC00;
}

  if(i!=0) if(__ProgFileSec(SecBuff, pCluster)!= OK) return WR_ERR; // write data
  if(__CloseFile(SecBuff, FileSize, pCluster, pDirAddr)!= OK) return WR_ERR;	//2nd var just seems to be size stamp, alterbios 
  return 0;                                                                     //does not seem to care 
}

u8 Load_Bmp(u8 FileNum){
  u8  i,y,start,FinishFactor;
  u16 j,h,x;
  char Filename[13] = "IMAG    BMP"; 
  
  u16 pCluster[3];
  u32 pDirAddr[1]; 
  
  if (Make_Filename(FileNum, Filename)!=0) return 1;
  i = __OpenFileRd(SecBuff, Filename, pCluster, pDirAddr);
  if(i != OK) return i;
  if(__ReadFileSec(SecBuff, pCluster)!= OK) return RD_ERR;

  if(flash_mode==FLASH_8M)FinishFactor=8; else FinishFactor=1;

  if(SecBuff[28]==16){						//if file is 64k color type
    x=0;
    y=0;
    for(h=0; h<(376/FinishFactor); h++){
      if(h==0)start=66;else start=0;
      for(j=start;j<(512*FinishFactor);j+=2){
        __Point_SCR(x,y);
        __LCD_SetPixl(((u16)(SecBuff[j+1]<<8))|SecBuff[j]);
        if(x<399)x++;else {x=0;y++;}
        if((x>=399)&&(y>=239))goto EndOfFile;
      }
      if(__ReadFileSec(SecBuff, pCluster)!= OK) return RD_ERR;
    }
  }else if(SecBuff[28]==4){					//16 color type
    x=0;
    y=0;
    for(h=0; h<(94/FinishFactor); h++){
      if(h==0)start=0x0076;else start=0;
      for(j=start;j<(512*FinishFactor);j++){
        __Point_SCR(x,y);
        __LCD_SetPixl(BMP_Color[SecBuff[j]>>4]);      
        __Point_SCR(x+1,y);
        __LCD_SetPixl(BMP_Color[SecBuff[j]&0x0F]);      
        if(x<398)x+=2;else {x=0;y++;}
        if((x>=398)&&(y>=239))goto EndOfFile;
      }
      if(__ReadFileSec(SecBuff, pCluster)!= OK) return RD_ERR;
    }  
  }  

EndOfFile:
  return 0;
}


/*******************************************************************************
Save_Buf: save the data collection buffer in BUF format		input: file number		return value: 0x00 = successful
*******************************************************************************/
u8 Save_Buf(u8 FileNum)
{
  u8   i;
  char Filename[12] = "DATA    BUF"; 
  u16* p ;
  
  u16 pCluster[3];
  u32 pDirAddr[1]; 
  
  if (Make_Filename(FileNum, Filename)!=0) return 1;
  if(__OpenFileWr(SecBuff, Filename, pCluster, pDirAddr)!=OK) return DISK_ERR;
  for(i=0; i<(BUFFER_SIZE/SectorSize); i++){
    memcpy(SecBuff, &(DataBuf[i*SectorSize/4]), SectorSize);
    if(__ProgFileSec(SecBuff, pCluster)!= OK) return WR_ERR; // write data        
    Print_Clk((i >>1)& 3);        // progress indication                         
  }
  memset(SecBuff, 0, 512);
  p =(u16*)SecBuff;
  for(i=0; i<4; i++){                     // save each corresponding value in the display menu
    *p++ = Title[i][0].Value;
    *p++ = Title[i][1].Value;
    *p++ = Title[i][2].Value;
    *p++ = Title[i][3].Value;
  }
  *p++ = Title[6][0].Value;
  *p++ = Title[6][1].Value;

  *p++ = 0x00FF & Ka1[_A_Range];
  *p++ = Ka2[_A_Range];
  *p++ = 0x00FF & Kb1[_B_Range];
  *p++ = Kb2[_B_Range];

  if(__ProgFileSec(SecBuff, pCluster)!= OK) return WR_ERR; // write data
  if(__CloseFile(SecBuff, 0x4200, pCluster, pDirAddr)!= OK) return WR_ERR;
  return 0;
}
/*******************************************************************************
Load_Buf: load saved data into acquisition buffer		input: file number		return value: 0x00 = successful
*******************************************************************************/
u8 Load_Buf(u8 FileNum)
{
  u8  i,j;
  char Filename[13] = "DATA    BUF"; 
  u16 *p;
  
  u16 pCluster[3];
  u32 pDirAddr[1]; 
  
  p = TempPar;
  *p++ = 0xAA55;
  for(i=0; i<4; i++){                     // save each corresponding value in the display menu
    *p++ = Title[i][0].Value;
    *p++ = Title[i][1].Value;
    *p++ = Title[i][2].Value;
    *p++ = Title[i][3].Value;
  }
  *p++ = Title[6][0].Value;
  *p++ = Title[6][1].Value;
  for(i=0; i<8; i++){
    *p++ = 0x00FF & Ka1[i];
    *p++ = Ka2[i];
    *p++ = 0x00FF & Kb1[i];
    *p++ = Kb2[i];
  }

  if (Make_Filename(FileNum, Filename)!=0) return 1;
  i = __OpenFileRd(SecBuff, Filename, pCluster, pDirAddr);
  if(i != OK) return i;
  for(i=0; i<((BUFFER_SIZE/SectorSize)); i++){
    if(__ReadFileSec(SecBuff, pCluster)!= OK) return RD_ERR;
    memcpy(&(DataBuf[i*SectorSize/4]),SecBuff,SectorSize);
  }
  if(__ReadFileSec(SecBuff, pCluster)!= OK) return RD_ERR;
  p =(u16*)SecBuff;
  for(i=0; i<4; i++){
    for(j=0;j<4;j++){
      Title[i][j].Value = *p++;             // restore
      Title[i][j].Flag  = UPDAT;
    }
  }
  Title[6][0].Value = *p++;
  Title[6][1].Value = *p++;
  Title[6][0].Flag  = UPDAT;
  Title[6][1].Flag  = UPDAT;
      
  Ka1[_A_Range] = (*p++ );
  Ka2[_A_Range] = (*p++ );
  Kb1[_B_Range] = (*p++);
  Kb2[_B_Range] = (*p++); 

  Title[RUNNING][STATE].Value = 1;                 // set to "HOLD" status
  Title[RUNNING][STATE].Flag |= UPDAT;             // set the update flag
  return 0;
}


void reset_parameter(void)
{
  u16* p;
  u8   i,j;
  
  p=TempPar;
  p++;
  if(TempPar[0]!=0xAA55) return;
  for(i=0; i<4; i++){
    for(j=0;j<4;j++){
      Title[i][j].Value = *p++;             // restore
      Title[i][j].Flag  = UPDAT;
    }
  }
  Title[6][0].Value = *p++;
  Title[6][1].Value = *p++;
  Title[6][0].Flag  = UPDAT;
  Title[6][1].Flag  = UPDAT;
  
  for(i=0; i<8; i++){
    Ka1[i] = (s8)(*p++ );//& 0xff);
    Ka2[i] = (*p++ );
    Kb1[i] = (s8)(*p++);// & 0xff);
    Kb2[i] = (*p++);
  }
  p = TempPar;
  *p++ = 0;
}

void make_Vertical(u8 TRACK,char* buf,u8* len)
{
  u8 i=0;
  char* ptr;

  ptr = &Vertical[0][0] + 10*Title[TRACK][2].Value;
  while(*ptr != 0){
    if(*ptr == 0x21)  buf[i] = 0x20;
    else              buf[i] = *ptr;
    ptr++;
    i++;
  };
  buf[i]   = 0x2c;
  buf[i+1] = 0;
  *len = i+1;
}
/*******************************************************************************
Save_Csv: save the acquisition buffer in CSV format		input: file number		return value: 0x00 = successful
*******************************************************************************/
u8 Save_Csv(u8 FileNum)
{
  u8  track[4];
  char Num[4];
  char Filename[12] = "DATA    CSV"; 
  u32 i, k = 0,length = SectorSize;
  s16 temp;
  u8  count, j, n = 0;
  
  u16 pCluster[3];
  u32 pDirAddr[1]; 

  Make_Filename(FileNum, Filename);
  length = SectorSize;			//In case not previously initiated on boot (parameter file may not exist)get from make_filename		
  if(__OpenFileWr(SecBuff, Filename, pCluster, pDirAddr)!=OK) return DISK_ERR;
  memcpy(SecBuff, "TRACK1 ", 7);
  make_Vertical(TRACK1, (char*)&SecBuff[7], &count);
  k = 7 + count;
  memcpy(&SecBuff[k], "TRACK2 ", 7);
  make_Vertical(TRACK2, (char*)&SecBuff[k+7], &count);
  k += 7 + count;
  memcpy(&SecBuff[k], "TRACK3,TRACK4,\r\n", 15);
  k += 15;
  for(i=0; i<4096; i++){
    temp=Ka1[_A_Range]+((Ka2[_A_Range]*((DataBuf[i] & 0xff)-ADCoffset))+512)/1024;
    if(temp > 0){
      if(temp > 200)  track[0] = 199;
      else            track[0] = temp;
    } else            track[0] = 0;
    temp = Kb1[_B_Range]+((Kb2[_B_Range]*(((DataBuf[i] & 0xff00)>>8)-ADCoffset))+512)/1024;
    if(temp > 0){
      if(temp > 200)  track[1] = 199;
      else            track[1] = temp;
    } else            track[1] = 0;
    if((DataBuf[i] & 0x010000)==0)  track[2] = Title[TRACK3][POSI].Value;
    else                            track[2] = 20 + Title[TRACK3][POSI].Value;
    if((DataBuf[i] & 0x020000)==0)  track[3] = Title[TRACK4][POSI].Value;
    else                            track[3] = 20 + Title[TRACK4][POSI].Value;
    for(j=0; j<4; j++){
      u8ToDec3(Num, track[j],0);
      for(count=0; count<3; count++){
        if(Num[count] == 0) break;
        SecBuff[k++] = Num[count];
        if(k >= length){
          if(__ProgFileSec(SecBuff, pCluster)!= OK) return WR_ERR; // write data
          Print_Clk((n++ >>1)& 3);    // progress indicator
          k = 0;
        }
      }
      SecBuff[k++] = 0x2c;
      if(k >= length){
        if(__ProgFileSec(SecBuff, pCluster)!= OK) return WR_ERR; // write data
        Print_Clk((n++ >>1)& 3);    // progress indicator
        k = 0;
      }
    }
    SecBuff[k++] = 0x0d;
    if(k >= length){
      if(__ProgFileSec(SecBuff, pCluster)!= OK) return WR_ERR; // write data
      Print_Clk((n++ >>1)& 3);    // progress indicator
      k = 0;
    }
    SecBuff[k++] = 0x0a;
    if(k >= length){
      if(__ProgFileSec(SecBuff, pCluster)!= OK) return WR_ERR; // write data
      Print_Clk((n++ >>1)& 3);    // progress indicator
      k = 0;
    }
  }
  if(k != 0){
    SecBuff[k++]=0x0d;
    SecBuff[k++]=0x0a;
    memset(&SecBuff[k],0,(length-k));
    k=0;
    if(__ProgFileSec(SecBuff, pCluster)!= OK) return WR_ERR; // write data
    Print_Clk((n >>1)& 3);    // progress indicator
  }
  if(__CloseFile(SecBuff, n*length, pCluster, pDirAddr)!= OK) return WR_ERR;
  return OK;
}
/*******************************************************************************
Load_Parameter: ����֮ǰ�Ĺ�������                           Return: 0= Success
*******************************************************************************/
u8 Load_Param(u8 FileNum)
{ 
  u8  Sum = 0; 
  char Filename[12]="CONF    CFG";
  u16 i;
  u16* p =(u16*)SecBuff;
  
  u16 pCluster[3];
  u32 pDirAddr[1]; 
  Versions = 0x06;
  
  if(FileNum==0){
    Word2Hex(Filename, __GetDev_SN());
    if (InitFileSystem()!=0) return 1;
    Filename[8] = 'W'; Filename[9] = 'P'; Filename[10] = 'T';
  }else Make_Filename(FileNum, Filename);

  i = __OpenFileRd(SecBuff, Filename, pCluster, pDirAddr);
  if(i != OK) return i;

  if(__ReadFileSec(SecBuff, pCluster)!= OK) return RD_ERR;

  //if((Versions !=(*p & 0xFF))&&((Versions+0x10)!=(*p & 0xFF))) return VER_ERR;          // works with either V6 or V 0x16
  if(Versions !=(*p & 0xFF)) return VER_ERR;          
  Versions=(*p & 0xFF);

  for(i=0; i<512; ++i) Sum += SecBuff[i];
  if(Sum != 0) return SUM_ERR;                        // checksum error
  Current =(*p++ >>8);                                // restore Current Title
  for(i=0; i<7; i++){ 
    Detail[i*2]  = *p;
    Detail[i*2+1]= (*p++ >>8);                        // restore Detail
  }
  for(i=0; i<13; i++){
    Title[i][0].Value = *p++;                         //restore each corresponding value in the display menu
    Title[i][1].Value = *p++;
    Title[i][2].Value = *p++;
    Title[i][3].Value = *p++;
  }
  for(i=0; i<9; i++){
    Meter[i].Item     = *p;
    Meter[i].Track    =(*p++ >>8);       // load measurements and the measurement object
	  }

 if(FileNum==0){
  for(i=0; i<10; i++){
    Ka1[i] = *p;                         // restore the original channel A low error correction coefficient
    Kb1[i] =(*p++ >>8);                  // restore the original B-channel low error correction coefficient
    Ka2[i] = *p++;                       // restore the original channel A gain error correction factor
    Kb2[i] = *p++;                       // restore the B-channel gain error correction coefficient
    Ka3[i] = *p;                         // restore the original channel A high error correction coefficient
    Kb3[i] =(*p++ >>8);                  // restore the original B-channel high error correction factor
  }
 }else{					 // do not load correction factors if not loading boot config
    p+=40;				 // allows updating calibration without interference from different configs
 }

 
  V_Trigg[A].Value = *p++;
  V_Trigg[B].Value = *p++;               // restore the original A and B channel trigger threshold
  FlagFrameMode= *p;
  CurDefTime=(*p++ >>8);                 // CurDefTime w/flagframemode  
  FlagMeter= *p;
  UpdateMeter=(*p++ >>8);		     // add additional values in a way compatible with original version   	
  TrgAuto=*p;
  CalFlag=(*p++ >>8);			     // add CalFlag	
  OffsetX=*p;
  SaveShortBuffXpos=(*p++ >>8);	     // add Short Buffer Xpos	
  OffsetY=*p;
  Options=(*p++ >>8);			     // add Options

 if(FileNum==0){
    LoBatLevel[0]=*p++;
    LoBatLevel[1]=*p++;
    HiBatLevel[0]=*p++;
    HiBatLevel[1]=*p++;
    for(i=0; i<10; i++){				
      LKa1[i] = *p;                         
      LKb1[i] =(*p++ >>8);               
      LKa2[i] = *p++;                      
      LKb2[i] = *p++;                   
      LKa3[i] = *p;                       
      LKb3[i] =(*p++ >>8);
    }                
    for(i=0; i<10; i++){
      HKa1[i] = *p;                       
      HKb1[i] =(*p++ >>8);               
      HKa2[i] = *p++;                      
      HKb2[i] = *p++;                       
      HKa3[i] = *p;                         
      HKb3[i] =(*p++ >>8);                  
    }
    PPM_Comp = *p++;
  }else p+=85;

    PerstFrameNumber = *p++;
    Raw = *p++;
    GenFreqShift = *p++;
    GenAdjustMode = *p++;

    if(FileNum==0){
      Sum=*p;  
      if((*p++>>8)==0xAB)ADCoffset=Sum; else ADCoffset=54;     //0xAB "key" assures default of 54 if ADCoffset value not originally saved         
    }

  return OK;
}
/*******************************************************************************
 Save_Parameter: save the current operating parameters		Return: 0= Success
*******************************************************************************/
u8 Save_Param(u8 FileNum)             // save the operating parameters table
{
  u8  Sum = 0;	 
  char Filename[12]="CONF    CFG";
  u16 i, Tmp[2];
  u16* p =(u16*)SecBuff;
  u8 transfer;  
  u8 MissingFileFlag=1;

  u16 pCluster[3];
  u32 pDirAddr[1]; 
  if (InitFileSystem()!=0) return 1;
  Versions=0x06;

  if(FileNum==0){
    Word2Hex(Filename, __GetDev_SN());
    Filename[8] = 'W'; Filename[9] = 'P'; Filename[10] = 'T';
  }else Make_Filename(FileNum, Filename);

  switch (__OpenFileRd(SecBuff, Filename, pCluster, pDirAddr)){
  case OK:                                                     // original WPT file exists
    MissingFileFlag=0;
    Tmp[0] = *pCluster;
  if(FileNum==0){     
    Filename[8] = 'B'; Filename[9] = 'A'; Filename[10] = 'K';  // turn into a BAK file
    if(__OpenFileWr(SecBuff, Filename, pCluster, pDirAddr)!= OK) return DISK_ERR;
    if(__ReadFileSec(SecBuff, Tmp     )!= OK) return RD_ERR;
    if(__ProgFileSec(SecBuff, pCluster)!= OK) return WR_ERR;  // save the BAK file
    if(__CloseFile(SecBuff, 512, pCluster, pDirAddr)!= OK) return WR_ERR;/**/
  }else{
    if(__OpenFileWr(SecBuff, Filename, pCluster, pDirAddr)!= OK) return DISK_ERR;
    memset(SecBuff, 0, SectorSize);
  } 
  case NEW:                                                    // original WPT file does not exist
  if(FileNum==0){     
    Filename[8] = 'W'; Filename[9] = 'P'; Filename[10] = 'T';  // create WPT files
    if(__OpenFileWr(SecBuff, Filename, pCluster, pDirAddr)!= OK) return DISK_ERR;
    memset(SecBuff, 0, 512);
  }else if(MissingFileFlag==1)return WR_ERR; // do not write new additional config files unless they already exist to prevent corruption			     	
    *p++ =(Current <<8)+ Versions;           // save the parameter table version number and the current Title

    for(i=0; i<7; i++){ 
      *p++ =(Detail[i*2+1]<<8)+ Detail[i*2]; // Save the Detail
    }
    for(i=0; i<13; i++){                     // Save display each value of the corresponding item in the menu
      *p++ = Title[i][0].Value;
      *p++ = Title[i][1].Value;
      *p++ = Title[i][2].Value;
      *p++ = Title[i][3].Value;
    }
    for(i=0; i<9; i++){
      *p++ =(Meter[i].Track<<8)+ Meter[i].Item;    // Save the measurement items and measurement object
    }
    for(i=0; i<10; i++){
      transfer=Ka1[i];				   //load into unsigned var first, prevents error with added signed CH-A value spilling over into shifted CH-B when negative	
      *p++ = (Kb1[i]<<8)+ transfer;             
      *p++ =  Ka2[i];                              // save the current channel A gain error correction coefficient
      *p++ =  Kb2[i];                              // save the current B-channel gain error correction factor
      transfer=Ka3[i];
      *p++ = (Kb3[i]<<8)+ transfer;
    }
    *p++ = V_Trigg[A].Value;
    *p++ = V_Trigg[B].Value;                  // save the current A and B channels trigger threshold
    *p++ = (CurDefTime<<8)+FlagFrameMode;     // include Cursor defined selection 
    *p++ = (UpdateMeter<<8)+FlagMeter;        // include meter "page" along with flag		
    *p++ = (CalFlag<<8)+TrgAuto;		    // include wave amplitude calibration flag	
    *p++ = (SaveShortBuffXpos<<8)+OffsetX;    // include short buffer xpos
    *p++ = (Options<<8)+OffsetY; 		    // include Options
    *p++ = LoBatLevel[0];
    *p++ = LoBatLevel[1];
    *p++ = HiBatLevel[0];
    *p++ = HiBatLevel[1];
    for(i=0; i<10; i++){			//save low batt level data
      transfer=LKa1[i];				  
      *p++ = (LKb1[i]<<8)+ transfer;             
      *p++ =  LKa2[i];                             
      *p++ =  LKb2[i];                            
      transfer=LKa3[i];
      *p++ = (LKb3[i]<<8)+ transfer;
    }
    for(i=0; i<10; i++){			//save high batt level data
      transfer=HKa1[i];				   
      *p++ = (HKb1[i]<<8)+ transfer;             
      *p++ =  HKa2[i];                             
      *p++ =  HKb2[i];                              
      transfer=HKa3[i];
      *p++ = (HKb3[i]<<8)+ transfer;
    }
    *p++ = PPM_Comp;
    *p++ = PerstFrameNumber;			
    *p++ = Raw;
    *p++ = GenFreqShift;
    *p++ = GenAdjustMode;
    *p++ = (0xAB<<8)+ADCoffset;		      //use 0xAB as id key to insure reload picks up only saved value  	
	
    for(i=0; i<511; i++)  Sum += SecBuff[i];  // calculate the parameter table checksum
    SecBuff[511] = (~Sum)+ 1;
    if(__ProgFileSec(SecBuff, pCluster)!= OK) return WR_ERR; // write data
    if(__CloseFile(SecBuff, 512, pCluster, pDirAddr)!= OK) return WR_ERR;
    return OK;
    default:  return WR_ERR;
  }
}

/******************************** END OF FILE *********************************/

