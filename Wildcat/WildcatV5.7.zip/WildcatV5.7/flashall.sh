 ./stm32flash -v /dev/ttyUSB0 -w APP1A.BIN -S 0x0800c000:64896
 ./stm32flash -v /dev/ttyUSB0 -w APP1B.BIN -S 0x08040000:52276
